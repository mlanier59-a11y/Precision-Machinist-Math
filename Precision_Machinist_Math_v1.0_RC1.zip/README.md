# Precision Machinist Math — v1.0 RC1

Release Candidate 1 is frozen from the device-validated CONSOLIDATED_REV1B baseline.

Version: 1.0.0-rc1
Version code: 2

REV1B validation confirmed:
- Three-Pin Find Best and Calculate Bore behavior, including keyboard/focus cleanup.
- Sine Bar keyboard/focus cleanup and integer-only DMS entry.
- Numeric first-focus Select All behavior across tested screens.
- Clear/focus behavior cleanup.
- Countersink unit selector standardized to INCH left / METRIC right.
- Previously validated machining calculations and reference outputs remain unchanged.

RC1 intentionally makes no calculation or reference-table changes from REV1B. Only release/version metadata and documentation were updated.
