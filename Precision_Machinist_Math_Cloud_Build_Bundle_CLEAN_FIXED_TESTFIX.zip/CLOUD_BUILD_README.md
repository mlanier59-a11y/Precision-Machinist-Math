# Precision Machinist Math — Beta 2 cloud build

This project is prepared to build on GitHub Actions without Android Studio, a local Android SDK, or a local Gradle installation.

1. Upload the contents of this project to the repository, preserving `app/...` and the project files.
2. The existing repository workflow can unpack this ZIP as its build source.
3. Push to `main`, or use **Actions → Build Precision Machinist Math APK → Run workflow**.
4. Download the artifact named `Precision-Machinist-Math-beta1-debug` (the workflow artifact name may be kept unchanged for the beta test).

The cloud build uses JDK 17, Android SDK platform 35/build tools 35.0.0, and Gradle 8.9.

## Beta 2 changes
- App title corrected to **Precision Machinist Math**.
- Three-pin suggested pins are separate read-only boxes at 3 decimals.
- Three-pin input focus sequence: Bore → Pin 1 → Pin 2 → Pin 3; Calculate Bore returns focus to Pin 3; Clear returns to Bore.
- Thread calculator now has clearly separated INCH/METRIC choices and correct mode-specific fields/formulas.
- Thread calculator includes tap-drill and thread-percentage calculation modes.
- Metric fits/tolerances lookup implemented from the supplied workbook data, including hole/shaft case checking.
- Countersink reference lookup implemented using the supplied 90° metric / 82° inch data and stated below-flush offsets.
- Hardness reference lookup implemented from the supplied table and explicitly labeled approximate/reference only.
- Sine bar supports decimal degrees and DMS, with inch/metric unit memory.
- Error states use a visible warning panel and haptic feedback on transition into error.
- Existing verified triangle and three-pin math retained.

No Excel workbook is included in the app and no workbook formulas are exposed to the user.
