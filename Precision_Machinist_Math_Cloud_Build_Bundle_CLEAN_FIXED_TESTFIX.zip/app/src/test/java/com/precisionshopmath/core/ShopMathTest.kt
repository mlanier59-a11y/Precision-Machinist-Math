package com.precisionshopmath.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ShopMathTest {
    private fun near(a: Double,b:Double,t:Double=1e-9) = assertTrue("$a != $b", abs(a-b) <= t)

    @Test fun threePinWorkbookExample() {
        val r=ThreePinMath.boreDiameter(.9728,.9718,.9038).value!!
        near(r,2.048033612,1e-9)
    }
    @Test fun threePinEstimatorIsExactBeforeDisplayRounding() {
        val e=ThreePinMath.estimatePins(2.0475).value!!
        val b=ThreePinMath.boreDiameter(e.pin1,e.pin2,e.pin3).value!!
        near(b,2.0475,1e-10)
    }
    @Test fun triangleWorkbookExample() {
        val r=TriangleMath.solve(aDeg=3.43363036245053,y=.7675).value!!
        near(r.x,12.79166667,1e-7); near(r.r,12.81467098,1e-7); near(r.bDeg,86.56636963754947,1e-10)
    }
    @Test fun triangleAllNinePairs() {
        val cases=listOf(
            TriangleMath.solve(aDeg=30.0,x=5.0), TriangleMath.solve(aDeg=30.0,y=2.886751345948129), TriangleMath.solve(aDeg=30.0,r=5.773502691896258),
            TriangleMath.solve(bDeg=60.0,x=5.0), TriangleMath.solve(bDeg=60.0,y=2.886751345948129), TriangleMath.solve(bDeg=60.0,r=5.773502691896258),
            TriangleMath.solve(x=5.0,y=2.886751345948129), TriangleMath.solve(x=5.0,r=5.773502691896258), TriangleMath.solve(y=2.886751345948129,r=5.773502691896258))
        cases.forEach { assertTrue(it.ok); near(it.value!!.aDeg,30.0,1e-9); near(it.value!!.x,5.0,1e-8); near(it.value!!.y,2.886751345948129,1e-8); near(it.value!!.r,5.773502691896258,1e-8) }
    }
    @Test fun sineBar() { near(SineBarMath.stackHeight(30.0,5.0).value!!,2.5,1e-12) }
    @Test fun metricAndInchThread() {
        near(ThreadMath.metricTapDrill(10.0,1.5,75.0).value!!,8.53858 ,1e-9)
        near(ThreadMath.inchTapDrill(.375,32.0,75.0).value!!,.34455375,1e-12)
    }
}
