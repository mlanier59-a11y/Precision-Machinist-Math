# Precision Machinist Math

Offline Android pocket calculator for precision machine-shop math.

Beta 2 includes three-pin bore measurement, thread calculations, right-triangle math, sine-bar setup, metric fits/tolerances, countersink reference, and hardness reference.

The calculation engine is kept separate from the Android UI and is covered by unit tests. Display values are rounded only for presentation; calculations retain full `Double` precision without intermediate display rounding.
