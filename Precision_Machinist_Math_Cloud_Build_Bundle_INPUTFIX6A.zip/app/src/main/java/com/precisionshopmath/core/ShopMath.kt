package com.precisionshopmath.core

import kotlin.math.*

enum class UnitSystem { INCH, METRIC }
data class ThreePinEstimate(val pin1: Double, val pin2: Double, val pin3: Double)
data class TriangleResult(val aDeg: Double, val bDeg: Double, val x: Double, val y: Double, val r: Double)
data class CalcError(val message: String)
data class CalcResult<T>(val value: T? = null, val error: CalcError? = null) { val ok get() = error == null }
data class Dev(val upperUm: Double, val lowerUm: Double)
data class ToleranceResult(val upperUm: Double,val lowerUm: Double,val upperMm: Double,val lowerMm: Double,val upperLimitMm: Double,val lowerLimitMm: Double)
data class Hard(val hb: Double?,val hra: Double?,val hrb: Double?,val hrc: Double?,val tensilePsi: Double?)
data class HardnessResult(val hb:Double?,val hra:Double?,val hrb:Double?,val hrc:Double?,val tensilePsi:Double?)


object ThreePinMath {
    fun boreDiameter(pin1: Double, pin2: Double, pin3: Double): CalcResult<Double> {
        if (!listOf(pin1,pin2,pin3).all { it.isFinite() && it > 0 }) return CalcResult(error=CalcError("All three pin diameters must be greater than zero."))
        val k1=2.0/pin1; val k2=2.0/pin2; val k3=2.0/pin3
        val rad=k1*k2+k1*k3+k2*k3
        if (!rad.isFinite() || rad<=0) return CalcResult(error=CalcError("Pin combination cannot form a valid bore."))
        val kb=k1+k2+k3-2.0*sqrt(rad)
        if (!kb.isFinite() || kb>=0) return CalcResult(error=CalcError("These pins cannot fit as three contacting pins in a bore."))
        val bore=-2.0/kb
        return if (bore.isFinite() && bore>0) CalcResult(value=bore) else CalcResult(error=CalcError("These pins do not produce a valid bore."))
    }
    fun estimatePins(targetBore: Double): CalcResult<ThreePinEstimate> {
        if (!targetBore.isFinite() || targetBore<=0) return CalcResult(error=CalcError("Target bore diameter must be greater than zero."))
        val p1=targetBore*0.475; val delta=min(0.001,targetBore*0.0005); val p2=p1-delta
        if (p2<=0) return CalcResult(error=CalcError("Target bore is too small for a practical pin estimate."))
        val k1=2.0/p1; val k2=2.0/p2; val targetK=-2.0/targetBore; val s=k1+k2
        val b=-2.0*(s+targetK); val c=(s-targetK)*(s-targetK)-4.0*k1*k2; val disc=b*b-4.0*c
        if (!disc.isFinite() || disc<=0) return CalcResult(error=CalcError("No valid three-pin estimate exists for this bore size."))
        val t1=(-b+sqrt(disc))/2.0; val t2=(-b-sqrt(disc))/2.0
        val candidates=listOf(t1,t2).filter{it.isFinite()&&it>0}.map{2.0/it}.sortedDescending()
        return if(candidates.isEmpty()) CalcResult(error=CalcError("No valid third-pin estimate exists.")) else CalcResult(value=ThreePinEstimate(p1,p2,candidates.first()))
    }
}

object TriangleMath {
    fun solve(aDeg:Double?=null,bDeg:Double?=null,x:Double?=null,y:Double?=null,r:Double?=null):CalcResult<TriangleResult>{
        val vals=listOf(aDeg,bDeg,x,y,r)
        if(vals.any{it!=null && (!it.isFinite()||it<=0)}) return CalcResult(error=CalcError("All entered values must be greater than zero."))
        if(vals.count{it!=null}!=2) return CalcResult(error=CalcError("Enter exactly two dimensions or angles."))
        val A:Double; val B:Double; val X:Double; val Y:Double; val R:Double
        when{
            aDeg!=null&&x!=null->{A=aDeg;X=x;B=90-A;val z=Math.toRadians(A);Y=X*tan(z);R=X/cos(z)}
            aDeg!=null&&y!=null->{A=aDeg;Y=y;B=90-A;val z=Math.toRadians(A);X=Y/tan(z);R=Y/sin(z)}
            aDeg!=null&&r!=null->{A=aDeg;R=r;B=90-A;val z=Math.toRadians(A);X=R*cos(z);Y=R*sin(z)}
            bDeg!=null&&x!=null->{B=bDeg;X=x;A=90-B;val z=Math.toRadians(B);Y=X/tan(z);R=X/sin(z)}
            bDeg!=null&&y!=null->{B=bDeg;Y=y;A=90-B;val z=Math.toRadians(B);X=Y*tan(z);R=Y/cos(z)}
            bDeg!=null&&r!=null->{B=bDeg;R=r;A=90-B;val z=Math.toRadians(B);X=R*sin(z);Y=R*cos(z)}
            x!=null&&y!=null->{X=x;Y=y;R=hypot(X,Y);A=Math.toDegrees(atan2(Y,X));B=90-A}
            x!=null&&r!=null->{X=x;R=r;if(X>=R)return CalcResult(error=CalcError("Side X must be smaller than hypotenuse R."));Y=sqrt(R*R-X*X);A=Math.toDegrees(acos(X/R));B=90-A}
            y!=null&&r!=null->{Y=y;R=r;if(Y>=R)return CalcResult(error=CalcError("Side Y must be smaller than hypotenuse R."));X=sqrt(R*R-Y*Y);A=Math.toDegrees(asin(Y/R));B=90-A}
            else->return CalcResult(error=CalcError("That pair is not a valid right-triangle input combination."))
        }
        if(A<=0||B<=0||A>=90||B>=90||X<=0||Y<=0||R<=0||listOf(A,B,X,Y,R).any{!it.isFinite()}) return CalcResult(error=CalcError("Those values do not form a valid right triangle."))
        return CalcResult(value=TriangleResult(A,B,X,Y,R))
    }
}

object SineBarMath {
    fun stackHeight(angleDeg:Double,length:Double):CalcResult<Double>{
        if(!angleDeg.isFinite()||angleDeg<=0||angleDeg>=90)return CalcResult(error=CalcError("Angle must be greater than 0° and less than 90°."))
        if(!length.isFinite()||length<=0)return CalcResult(error=CalcError("Sine bar length must be greater than zero."))
        return CalcResult(value=length*sin(Math.toRadians(angleDeg)))
    }
    fun dmsToDecimal(deg:Double,min:Double,sec:Double):CalcResult<Double>{
        if(!listOf(deg,min,sec).all{it.isFinite()})return CalcResult(error=CalcError("Enter valid degrees, minutes, and seconds."))
        if(deg<=0||min<0||min>=60||sec<0||sec>=60)return CalcResult(error=CalcError("Use degrees > 0, minutes 0–59, and seconds 0–59."))
        val a=deg+min/60.0+sec/3600.0
        return if(a<90)CalcResult(value=a) else CalcResult(error=CalcError("Angle must be less than 90°."))
    }
}

object ThreadMath {
    private const val K60=1.29904
    fun metricTapDrill(majorMm:Double,pitchMm:Double,percent:Double):CalcResult<Double>{
        if(!listOf(majorMm,pitchMm,percent).all{it.isFinite()}||majorMm<=0||pitchMm<=0||percent<=0||percent>100)return CalcResult(error=CalcError("Enter a valid major diameter, pitch, and thread percentage."))
        val d=majorMm-(percent/100.0)*K60*pitchMm
        return if(d>0)CalcResult(value=d)else CalcResult(error=CalcError("Calculated tap drill is not positive; check diameter, pitch, and percentage."))
    }
    fun metricPercent(majorMm:Double,pitchMm:Double,drillMm:Double):CalcResult<Double>{
        if(!listOf(majorMm,pitchMm,drillMm).all{it.isFinite()}||majorMm<=0||pitchMm<=0||drillMm<=0||drillMm>=majorMm)return CalcResult(error=CalcError("Enter a valid major diameter, pitch, and drilled diameter."))
        return CalcResult(value=(majorMm-drillMm)/(K60*pitchMm)*100.0)
    }
    fun inchTapDrill(majorIn:Double,tpi:Double,percent:Double):CalcResult<Double>{
        if(!listOf(majorIn,tpi,percent).all{it.isFinite()}||majorIn<=0||tpi<=0||percent<=0||percent>100)return CalcResult(error=CalcError("Enter a valid major diameter, TPI, and thread percentage."))
        val d=majorIn-(percent/100.0)*K60/tpi
        return if(d>0)CalcResult(value=d)else CalcResult(error=CalcError("Calculated tap drill is not positive; check diameter, TPI, and percentage."))
    }
    fun inchPercent(majorIn:Double,tpi:Double,drillIn:Double):CalcResult<Double>{
        if(!listOf(majorIn,tpi,drillIn).all{it.isFinite()}||majorIn<=0||tpi<=0||drillIn<=0||drillIn>=majorIn)return CalcResult(error=CalcError("Enter a valid major diameter, TPI, and drilled diameter."))
        return CalcResult(value=(majorIn-drillIn)*tpi/K60*100.0)
    }
}

private val SIZE_STARTS=listOf(1.0,4.0,7.0,11.0,15.0,19.0,25.0,31.0,41.0,51.0,66.0,81.0,101.0,121.0,141.0,161.0,181.0,201.0,226.0,251.0,281.0,316.0,356.0,401.0,451.0)
private fun sizeIndex(mm:Double):Int? { if(!mm.isFinite()||mm<SIZE_STARTS.first()||mm>500.0)return null; var idx=0; for(i in SIZE_STARTS.indices) if(mm>=SIZE_STARTS[i]) idx=i else break; return idx }

private val HOLE_TOL = mapOf(
    "B10" to listOf(Dev(180.0,140.0),Dev(188.0,140.0),Dev(208.0,150.0),Dev(220.0,150.0),Dev(220.0,150.0),Dev(224.0,160.0),Dev(224.0,160.0),Dev(270.0,170.0),Dev(280.0,180.0),Dev(310.0,190.0),Dev(320.0,200.0),Dev(360.0,220.0),Dev(380.0,240.0),Dev(420.0,260.0),Dev(440.0,280.0),Dev(470.0,310.0),Dev(525.0,340.0),Dev(565.0,380.0),Dev(605.0,420.0),Dev(690.0,480.0),Dev(750.0,540.0),Dev(830.0,600.0),Dev(910.0,680.0),Dev(1010.0,760.0),Dev(1090.0,840.0)),
    "C9" to listOf(Dev(85.0,60.0),Dev(100.0,70.0),Dev(116.0,80.0),Dev(138.0,95.0),Dev(138.0,95.0),Dev(162.0,110.0),Dev(162.0,110.0),Dev(182.0,120.0),Dev(192.0,130.0),Dev(214.0,140.0),Dev(224.0,150.0),Dev(257.0,170.0),Dev(267.0,180.0),Dev(300.0,200.0),Dev(310.0,210.0),Dev(330.0,230.0),Dev(355.0,240.0),Dev(375.0,260.0),Dev(395.0,280.0),Dev(430.0,300.0),Dev(460.0,330.0),Dev(500.0,360.0),Dev(540.0,400.0),Dev(595.0,440.0),Dev(635.0,480.0)),
    "C10" to listOf(Dev(100.0,60.0),Dev(118.0,70.0),Dev(138.0,80.0),Dev(165.0,95.0),Dev(165.0,95.0),Dev(194.0,110.0),Dev(194.0,110.0),Dev(220.0,120.0),Dev(230.0,130.0),Dev(260.0,140.0),Dev(270.0,150.0),Dev(310.0,170.0),Dev(320.0,180.0),Dev(360.0,200.0),Dev(370.0,210.0),Dev(390.0,230.0),Dev(425.0,240.0),Dev(455.0,260.0),Dev(465.0,280.0),Dev(510.0,300.0),Dev(540.0,330.0),Dev(590.0,360.0),Dev(630.0,400.0),Dev(690.0,440.0),Dev(730.0,480.0)),
    "D8" to listOf(Dev(34.0,20.0),Dev(48.0,30.0),Dev(62.0,40.0),Dev(77.0,50.0),Dev(77.0,50.0),Dev(98.0,65.0),Dev(98.0,65.0),Dev(119.0,80.0),Dev(119.0,80.0),Dev(146.0,100.0),Dev(146.0,100.0),Dev(174.0,120.0),Dev(174.0,120.0),Dev(208.0,145.0),Dev(208.0,145.0),Dev(208.0,145.0),Dev(242.0,170.0),Dev(242.0,170.0),Dev(242.0,170.0),Dev(271.0,190.0),Dev(271.0,190.0),Dev(299.0,210.0),Dev(299.0,210.0),Dev(327.0,230.0),Dev(327.0,230.0)),
    "D9" to listOf(Dev(45.0,20.0),Dev(60.0,30.0),Dev(76.0,40.0),Dev(93.0,50.0),Dev(93.0,50.0),Dev(117.0,65.0),Dev(117.0,65.0),Dev(142.0,80.0),Dev(142.0,80.0),Dev(174.0,100.0),Dev(174.0,100.0),Dev(207.0,120.0),Dev(207.0,120.0),Dev(245.0,170.0),Dev(245.0,170.0),Dev(245.0,170.0),Dev(285.0,170.0),Dev(285.0,170.0),Dev(285.0,170.0),Dev(320.0,190.0),Dev(320.0,190.0),Dev(350.0,210.0),Dev(350.0,210.0),Dev(385.0,230.0),Dev(385.0,230.0)),
    "D10" to listOf(Dev(60.0,20.0),Dev(78.0,30.0),Dev(98.0,40.0),Dev(120.0,50.0),Dev(120.0,50.0),Dev(149.0,65.0),Dev(149.0,65.0),Dev(180.0,80.0),Dev(180.0,80.0),Dev(220.0,100.0),Dev(220.0,100.0),Dev(260.0,120.0),Dev(260.0,120.0),Dev(305.0,145.0),Dev(305.0,145.0),Dev(305.0,145.0),Dev(355.0,170.0),Dev(355.0,170.0),Dev(355.0,170.0),Dev(400.0,190.0),Dev(400.0,190.0),Dev(440.0,210.0),Dev(440.0,210.0),Dev(480.0,230.0),Dev(480.0,230.0)),
    "E7" to listOf(Dev(24.0,14.0),Dev(32.0,20.0),Dev(40.0,25.0),Dev(50.0,32.0),Dev(50.0,32.0),Dev(61.0,40.0),Dev(61.0,40.0),Dev(75.0,50.0),Dev(75.0,50.0),Dev(90.0,60.0),Dev(90.0,60.0),Dev(107.0,72.0),Dev(107.0,72.0),Dev(125.0,85.0),Dev(125.0,85.0),Dev(125.0,85.0),Dev(146.0,100.0),Dev(146.0,100.0),Dev(146.0,100.0),Dev(162.0,110.0),Dev(162.0,110.0),Dev(182.0,125.0),Dev(182.0,125.0),Dev(198.0,135.0),Dev(198.0,135.0)),
    "E8" to listOf(Dev(28.0,14.0),Dev(38.0,20.0),Dev(47.0,25.0),Dev(59.0,32.0),Dev(59.0,32.0),Dev(73.0,40.0),Dev(73.0,40.0),Dev(89.0,50.0),Dev(89.0,50.0),Dev(106.0,60.0),Dev(106.0,60.0),Dev(126.0,72.0),Dev(126.0,72.0),Dev(148.0,85.0),Dev(148.0,85.0),Dev(148.0,85.0),Dev(172.0,100.0),Dev(172.0,100.0),Dev(172.0,100.0),Dev(191.0,110.0),Dev(191.0,110.0),Dev(214.0,125.0),Dev(214.0,125.0),Dev(232.0,135.0),Dev(232.0,135.0)),
    "E9" to listOf(Dev(39.0,14.0),Dev(50.0,20.0),Dev(61.0,25.0),Dev(75.0,32.0),Dev(75.0,32.0),Dev(92.0,40.0),Dev(92.0,40.0),Dev(112.0,50.0),Dev(112.0,50.0),Dev(134.0,60.0),Dev(134.0,60.0),Dev(159.0,72.0),Dev(159.0,72.0),Dev(185.0,85.0),Dev(185.0,85.0),Dev(185.0,85.0),Dev(215.0,100.0),Dev(215.0,100.0),Dev(215.0,100.0),Dev(240.0,110.0),Dev(240.0,110.0),Dev(265.0,125.0),Dev(265.0,125.0),Dev(290.0,135.0),Dev(290.0,135.0)),
    "F6" to listOf(Dev(12.0,6.0),Dev(18.0,10.0),Dev(22.0,13.0),Dev(27.0,16.0),Dev(27.0,16.0),Dev(33.0,20.0),Dev(33.0,20.0),Dev(41.0,25.0),Dev(41.0,25.0),Dev(49.0,30.0),Dev(49.0,30.0),Dev(58.0,36.0),Dev(58.0,36.0),Dev(68.0,43.0),Dev(68.0,43.0),Dev(68.0,43.0),Dev(79.0,50.0),Dev(79.0,50.0),Dev(79.0,50.0),Dev(88.0,56.0),Dev(88.0,56.0),Dev(98.0,62.0),Dev(98.0,62.0),Dev(108.0,68.0),Dev(108.0,68.0)),
    "F7" to listOf(Dev(16.0,6.0),Dev(22.0,10.0),Dev(28.0,13.0),Dev(34.0,16.0),Dev(34.0,16.0),Dev(41.0,20.0),Dev(41.0,20.0),Dev(50.0,25.0),Dev(50.0,25.0),Dev(60.0,30.0),Dev(60.0,30.0),Dev(71.0,36.0),Dev(71.0,36.0),Dev(83.0,43.0),Dev(83.0,43.0),Dev(83.0,43.0),Dev(96.0,50.0),Dev(96.0,50.0),Dev(96.0,50.0),Dev(108.0,56.0),Dev(108.0,56.0),Dev(119.0,62.0),Dev(119.0,62.0),Dev(131.0,68.0),Dev(131.0,68.0)),
    "F8" to listOf(Dev(20.0,6.0),Dev(28.0,10.0),Dev(35.0,13.0),Dev(43.0,16.0),Dev(43.0,16.0),Dev(53.0,20.0),Dev(53.0,20.0),Dev(64.0,25.0),Dev(64.0,25.0),Dev(76.0,30.0),Dev(76.0,30.0),Dev(90.0,36.0),Dev(90.0,36.0),Dev(106.0,43.0),Dev(106.0,43.0),Dev(106.0,43.0),Dev(122.0,50.0),Dev(122.0,50.0),Dev(122.0,50.0),Dev(137.0,56.0),Dev(137.0,56.0),Dev(151.0,62.0),Dev(151.0,62.0),Dev(165.0,68.0),Dev(165.0,68.0)),
    "G6" to listOf(Dev(8.0,2.0),Dev(12.0,4.0),Dev(14.0,5.0),Dev(17.0,6.0),Dev(17.0,6.0),Dev(20.0,7.0),Dev(20.0,7.0),Dev(25.0,9.0),Dev(25.0,9.0),Dev(29.0,10.0),Dev(29.0,10.0),Dev(34.0,12.0),Dev(34.0,12.0),Dev(39.0,14.0),Dev(39.0,14.0),Dev(39.0,14.0),Dev(44.0,15.0),Dev(44.0,15.0),Dev(44.0,15.0),Dev(49.0,17.0),Dev(49.0,17.0),Dev(54.0,18.0),Dev(54.0,18.0),Dev(60.0,20.0),Dev(60.0,20.0)),
    "G7" to listOf(Dev(12.0,2.0),Dev(16.0,4.0),Dev(20.0,5.0),Dev(24.0,6.0),Dev(24.0,6.0),Dev(28.0,7.0),Dev(28.0,7.0),Dev(34.0,9.0),Dev(34.0,9.0),Dev(40.0,10.0),Dev(40.0,10.0),Dev(47.0,12.0),Dev(47.0,12.0),Dev(54.0,14.0),Dev(54.0,14.0),Dev(54.0,14.0),Dev(61.0,15.0),Dev(61.0,15.0),Dev(61.0,15.0),Dev(69.0,17.0),Dev(69.0,17.0),Dev(75.0,18.0),Dev(75.0,18.0),Dev(83.0,20.0),Dev(83.0,20.0)),
    "H6" to listOf(Dev(6.0,0.0),Dev(8.0,0.0),Dev(9.0,0.0),Dev(11.0,0.0),Dev(11.0,0.0),Dev(13.0,0.0),Dev(13.0,0.0),Dev(16.0,0.0),Dev(16.0,0.0),Dev(19.0,0.0),Dev(19.0,0.0),Dev(22.0,0.0),Dev(22.0,0.0),Dev(25.0,0.0),Dev(25.0,0.0),Dev(25.0,0.0),Dev(29.0,0.0),Dev(29.0,0.0),Dev(29.0,0.0),Dev(32.0,0.0),Dev(32.0,0.0),Dev(36.0,0.0),Dev(36.0,0.0),Dev(40.0,0.0),Dev(40.0,0.0)),
    "H7" to listOf(Dev(10.0,0.0),Dev(12.0,0.0),Dev(15.0,0.0),Dev(18.0,0.0),Dev(18.0,0.0),Dev(21.0,0.0),Dev(21.0,0.0),Dev(25.0,0.0),Dev(25.0,0.0),Dev(30.0,0.0),Dev(30.0,0.0),Dev(35.0,0.0),Dev(35.0,0.0),Dev(40.0,0.0),Dev(40.0,0.0),Dev(40.0,0.0),Dev(46.0,0.0),Dev(46.0,0.0),Dev(46.0,0.0),Dev(52.0,0.0),Dev(52.0,0.0),Dev(57.0,0.0),Dev(57.0,0.0),Dev(63.0,0.0),Dev(63.0,0.0)),
    "H8" to listOf(Dev(14.0,0.0),Dev(18.0,0.0),Dev(22.0,0.0),Dev(27.0,0.0),Dev(27.0,0.0),Dev(33.0,0.0),Dev(33.0,0.0),Dev(39.0,0.0),Dev(39.0,0.0),Dev(46.0,0.0),Dev(46.0,0.0),Dev(64.0,0.0),Dev(64.0,0.0),Dev(63.0,0.0),Dev(63.0,0.0),Dev(63.0,0.0),Dev(72.0,0.0),Dev(72.0,0.0),Dev(72.0,0.0),Dev(81.0,0.0),Dev(81.0,0.0),Dev(89.0,0.0),Dev(89.0,0.0),Dev(97.0,0.0),Dev(97.0,0.0)),
    "H9" to listOf(Dev(25.0,0.0),Dev(30.0,0.0),Dev(36.0,0.0),Dev(43.0,0.0),Dev(43.0,0.0),Dev(52.0,0.0),Dev(52.0,0.0),Dev(62.0,0.0),Dev(62.0,0.0),Dev(74.0,0.0),Dev(74.0,0.0),Dev(87.0,0.0),Dev(87.0,0.0),Dev(100.0,0.0),Dev(100.0,0.0),Dev(100.0,0.0),Dev(115.0,0.0),Dev(115.0,0.0),Dev(115.0,0.0),Dev(130.0,0.0),Dev(130.0,0.0),Dev(140.0,0.0),Dev(140.0,0.0),Dev(155.0,0.0),Dev(155.0,0.0)),
    "H10" to listOf(Dev(40.0,0.0),Dev(48.0,0.0),Dev(58.0,0.0),Dev(70.0,0.0),Dev(70.0,0.0),Dev(84.0,0.0),Dev(84.0,0.0),Dev(100.0,0.0),Dev(100.0,0.0),Dev(120.0,0.0),Dev(120.0,0.0),Dev(140.0,0.0),Dev(140.0,0.0),Dev(160.0,0.0),Dev(160.0,0.0),Dev(160.0,0.0),Dev(185.0,0.0),Dev(185.0,0.0),Dev(185.0,0.0),Dev(210.0,0.0),Dev(210.0,0.0),Dev(230.0,0.0),Dev(230.0,0.0),Dev(250.0,0.0),Dev(250.0,0.0)),
    "JS6" to listOf(Dev(3.0,-3.0),Dev(4.0,-4.0),Dev(4.5,-4.5),Dev(5.5,-5.5),Dev(5.5,-5.5),Dev(6.5,-6.5),Dev(6.5,-6.5),Dev(8.0,-8.0),Dev(8.0,-8.0),Dev(9.5,-9.5),Dev(9.5,-9.5),Dev(11.0,-11.0),Dev(11.0,-11.0),Dev(12.5,-12.5),Dev(12.5,-12.5),Dev(12.5,-12.5),Dev(14.5,-14.5),Dev(14.5,-14.5),Dev(14.5,-14.5),Dev(16.0,-16.0),Dev(16.0,-16.0),Dev(18.0,-18.0),Dev(18.0,-18.0),Dev(20.0,-20.0),Dev(20.0,-20.0)),
    "JS7" to listOf(Dev(5.0,-5.0),Dev(6.0,-6.0),Dev(7.0,-7.0),Dev(9.0,-9.0),Dev(9.0,-9.0),Dev(10.0,-10.0),Dev(10.0,-10.0),Dev(12.0,-12.0),Dev(12.0,-12.0),Dev(15.0,-15.0),Dev(15.0,-15.0),Dev(17.0,-17.0),Dev(17.0,-17.0),Dev(20.0,-20.0),Dev(20.0,-20.0),Dev(20.0,-20.0),Dev(23.0,-23.0),Dev(23.0,-23.0),Dev(23.0,-23.0),Dev(26.0,-26.0),Dev(26.0,-26.0),Dev(28.0,-28.0),Dev(28.0,-28.0),Dev(31.0,-31.0),Dev(31.0,-31.0)),
    "K6" to listOf(Dev(0.0,-6.0),Dev(2.0,-6.0),Dev(2.0,-7.0),Dev(2.0,-9.0),Dev(2.0,-9.0),Dev(2.0,-11.0),Dev(2.0,-11.0),Dev(3.0,-13.0),Dev(3.0,-13.0),Dev(4.0,-15.0),Dev(4.0,-15.0),Dev(4.0,-18.0),Dev(4.0,-18.0),Dev(4.0,-21.0),Dev(4.0,-21.0),Dev(4.0,-21.0),Dev(5.0,-24.0),Dev(5.0,-24.0),Dev(5.0,-24.0),Dev(5.0,-27.0),Dev(5.0,-27.0),Dev(7.0,-29.0),Dev(7.0,-29.0),Dev(8.0,-32.0),Dev(8.0,-32.0)),
    "K7" to listOf(Dev(0.0,-10.0),Dev(3.0,-9.0),Dev(5.0,-10.0),Dev(6.0,-12.0),Dev(6.0,-12.0),Dev(6.0,-15.0),Dev(6.0,-15.0),Dev(7.0,-18.0),Dev(7.0,-18.0),Dev(9.0,-21.0),Dev(9.0,-21.0),Dev(10.0,-25.0),Dev(10.0,-25.0),Dev(12.0,-28.0),Dev(12.0,-28.0),Dev(12.0,-28.0),Dev(13.0,-33.0),Dev(13.0,-33.0),Dev(13.0,-33.0),Dev(16.0,-36.0),Dev(16.0,-36.0),Dev(17.0,-40.0),Dev(17.0,-40.0),Dev(18.0,-45.0),Dev(18.0,-45.0)),
    "M6" to listOf(Dev(-2.0,-8.0),Dev(-1.0,-9.0),Dev(-3.0,-12.0),Dev(-4.0,-15.0),Dev(-4.0,-15.0),Dev(-4.0,-17.0),Dev(-4.0,-17.0),Dev(-4.0,-20.0),Dev(-4.0,-20.0),Dev(-5.0,-24.0),Dev(-5.0,-24.0),Dev(-6.0,-28.0),Dev(-6.0,-28.0),Dev(-8.0,-33.0),Dev(-8.0,-33.0),Dev(-8.0,-33.0),Dev(-8.0,-37.0),Dev(-8.0,-37.0),Dev(-8.0,-37.0),Dev(-9.0,-41.0),Dev(-9.0,-41.0),Dev(-10.0,-46.0),Dev(-10.0,-46.0),Dev(-10.0,-50.0),Dev(-10.0,-50.0)),
    "M7" to listOf(Dev(-2.0,-12.0),Dev(0.0,-12.0),Dev(0.0,-15.0),Dev(0.0,-18.0),Dev(0.0,-18.0),Dev(0.0,-21.0),Dev(0.0,-21.0),Dev(0.0,-25.0),Dev(0.0,-25.0),Dev(0.0,-30.0),Dev(0.0,-30.0),Dev(0.0,-35.0),Dev(0.0,-35.0),Dev(0.0,-40.0),Dev(0.0,-40.0),Dev(0.0,-40.0),Dev(0.0,-46.0),Dev(0.0,-46.0),Dev(0.0,-46.0),Dev(0.0,-52.0),Dev(0.0,-52.0),Dev(0.0,-57.0),Dev(0.0,-57.0),Dev(0.0,-63.0),Dev(0.0,-63.0)),
    "N6" to listOf(Dev(-4.0,-10.0),Dev(-5.0,-13.0),Dev(-7.0,-16.0),Dev(-9.0,-20.0),Dev(-9.0,-20.0),Dev(-11.0,-24.0),Dev(-11.0,-24.0),Dev(-12.0,-28.0),Dev(-12.0,-28.0),Dev(-14.0,-33.0),Dev(-14.0,-33.0),Dev(-16.0,-38.0),Dev(-16.0,-38.0),Dev(-20.0,-45.0),Dev(-20.0,-45.0),Dev(-20.0,-45.0),Dev(-22.0,-51.0),Dev(-22.0,-51.0),Dev(-22.0,-51.0),Dev(-25.0,-57.0),Dev(-25.0,-57.0),Dev(-26.0,-62.0),Dev(-26.0,-62.0),Dev(-27.0,-67.0),Dev(-27.0,-67.0)),
    "N7" to listOf(Dev(-4.0,-14.0),Dev(-4.0,-16.0),Dev(-4.0,-19.0),Dev(-5.0,-23.0),Dev(-5.0,-23.0),Dev(-7.0,-28.0),Dev(-7.0,-28.0),Dev(-8.0,-33.0),Dev(-8.0,-33.0),Dev(-9.0,-39.0),Dev(-9.0,-39.0),Dev(-10.0,-45.0),Dev(-10.0,-45.0),Dev(-12.0,-52.0),Dev(-12.0,-52.0),Dev(-12.0,-52.0),Dev(-14.0,-60.0),Dev(-14.0,-60.0),Dev(-14.0,-60.0),Dev(-14.0,-66.0),Dev(-14.0,-66.0),Dev(-16.0,-73.0),Dev(-16.0,-73.0),Dev(-17.0,-80.0),Dev(-17.0,-80.0)),
    "P6" to listOf(Dev(-6.0,-12.0),Dev(-9.0,-17.0),Dev(-12.0,-21.0),Dev(-15.0,-26.0),Dev(-15.0,-26.0),Dev(-18.0,-31.0),Dev(-18.0,-31.0),Dev(-21.0,-37.0),Dev(-21.0,-37.0),Dev(-26.0,-45.0),Dev(-26.0,-45.0),Dev(-30.0,-52.0),Dev(-30.0,-52.0),Dev(-36.0,-61.0),Dev(-36.0,-61.0),Dev(-36.0,-61.0),Dev(-41.0,-70.0),Dev(-41.0,-70.0),Dev(-41.0,-70.0),Dev(-47.0,-79.0),Dev(-47.0,-79.0),Dev(-51.0,-87.0),Dev(-51.0,-87.0),Dev(-55.0,-95.0),Dev(-55.0,-95.0)),
    "P7" to listOf(Dev(-6.0,-16.0),Dev(-8.0,-20.0),Dev(-9.0,-24.0),Dev(-11.0,-29.0),Dev(-11.0,-29.0),Dev(-14.0,-35.0),Dev(-14.0,-35.0),Dev(-17.0,-42.0),Dev(-17.0,-42.0),Dev(-21.0,-51.0),Dev(-21.0,-51.0),Dev(-24.0,-59.0),Dev(-24.0,-59.0),Dev(-28.0,-68.0),Dev(-28.0,-68.0),Dev(-28.0,-68.0),Dev(-33.0,-79.0),Dev(-33.0,-79.0),Dev(-33.0,-79.0),Dev(-36.0,-88.0),Dev(-36.0,-88.0),Dev(-41.0,-98.0),Dev(-41.0,-98.0),Dev(-45.0,-108.0),Dev(-45.0,-108.0)),
    "R7" to listOf(Dev(-10.0,-20.0),Dev(-11.0,-23.0),Dev(-13.0,-28.0),Dev(-16.0,-34.0),Dev(-16.0,-34.0),Dev(-20.0,-41.0),Dev(-20.0,-41.0),Dev(-25.0,-50.0),Dev(-25.0,-50.0),Dev(-30.0,-60.0),Dev(-32.0,-62.0),Dev(-38.0,-73.0),Dev(-41.0,-76.0),Dev(-48.0,-88.0),Dev(-50.0,-90.0),Dev(-53.0,-93.0),Dev(-60.0,-106.0),Dev(-63.0,-109.0),Dev(-67.0,-113.0),Dev(-74.0,-126.0),Dev(-78.0,-130.0),Dev(-87.0,-144.0),Dev(-93.0,-150.0),Dev(-103.0,-166.0),Dev(-109.0,-172.0)),
    "S7" to listOf(Dev(-14.0,-24.0),Dev(-15.0,-27.0),Dev(-17.0,-32.0),Dev(-21.0,-39.0),Dev(-21.0,-39.0),Dev(-27.0,-48.0),Dev(-27.0,-48.0),Dev(-34.0,-59.0),Dev(-34.0,-59.0),Dev(-42.0,-72.0),Dev(-48.0,-78.0),Dev(-58.0,-93.0),Dev(-66.0,-101.0),Dev(-77.0,-117.0),Dev(-85.0,-125.0),Dev(-93.0,-133.0),Dev(-105.0,-151.0),Dev(-113.0,-159.0),Dev(-123.0,-169.0),null,null,null,null,null,null),
    "T7" to listOf(null,null,null,null,null,null,Dev(-33.0,-54.0),Dev(-39.0,-64.0),Dev(-45.0,-70.0),Dev(-55.0,-85.0),Dev(-64.0,-94.0),Dev(-78.0,-113.0),Dev(-91.0,-126.0),Dev(-107.0,-147.0),Dev(-119.0,-159.0),Dev(-131.0,-171.0),null,null,null,null,null,null,null,null,null),
    "U7" to listOf(Dev(-18.0,-28.0),Dev(-19.0,-31.0),Dev(-22.0,-37.0),Dev(-26.0,-44.0),Dev(-26.0,-44.0),Dev(-33.0,-54.0),Dev(-40.0,-61.0),Dev(-51.0,-76.0),Dev(-61.0,-86.0),Dev(-76.0,-106.0),Dev(-91.0,-121.0),Dev(-111.0,-146.0),Dev(-131.0,-166.0),null,null,null,null,null,null,null,null,null,null,null,null),
    "X7" to listOf(Dev(-20.0,-30.0),Dev(-24.0,-36.0),Dev(-28.0,-43.0),Dev(-33.0,-51.0),Dev(-38.0,-56.0),Dev(-46.0,-67.0),Dev(-56.0,-77.0),null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
)

private val SHAFT_TOL = mapOf(
    "b9" to listOf(Dev(-140.0,-165.0),Dev(-140.0,-170.0),Dev(-150.0,-186.0),Dev(-150.0,-193.0),Dev(-150.0,-193.0),Dev(-160.0,-212.0),Dev(-160.0,-212.0),Dev(-170.0,-232.0),Dev(-180.0,-242.0),Dev(-190.0,-264.0),Dev(-200.0,-274.0),Dev(-220.0,-307.0),Dev(-240.0,-327.0),Dev(-260.0,-360.0),Dev(-280.0,-380.0),Dev(-310.0,-410.0),Dev(-340.0,-455.0),Dev(-380.0,-495.0),Dev(-420.0,-535.0),Dev(-480.0,-610.0),Dev(-540.0,-670.0),Dev(-600.0,-740.0),Dev(-680.0,-820.0),Dev(-760.0,-915.0),Dev(-840.0,-995.0)),
    "c9" to listOf(Dev(-60.0,-85.0),Dev(-70.0,-100.0),Dev(-80.0,-116.0),Dev(-95.0,-138.0),Dev(-95.0,-138.0),Dev(-110.0,-162.0),Dev(-110.0,-162.0),Dev(-120.0,-182.0),Dev(-130.0,-192.0),Dev(-140.0,-214.0),Dev(-150.0,-224.0),Dev(-170.0,-257.0),Dev(-180.0,-267.0),Dev(-200.0,-300.0),Dev(-210.0,-310.0),Dev(-230.0,-330.0),Dev(-240.0,-355.0),Dev(-260.0,-375.0),Dev(-280.0,-395.0),Dev(-300.0,-430.0),Dev(-330.0,-460.0),Dev(-360.0,-500.0),Dev(-400.0,-540.0),Dev(-440.0,-595.0),Dev(-480.0,-635.0)),
    "d8" to listOf(Dev(-20.0,-34.0),Dev(-30.0,-48.0),Dev(-40.0,-62.0),Dev(-50.0,-77.0),Dev(-50.0,-77.0),Dev(-65.0,-98.0),Dev(-65.0,-98.0),Dev(-80.0,-119.0),Dev(-80.0,-119.0),Dev(-100.0,-146.0),Dev(-100.0,-146.0),Dev(-120.0,-174.0),Dev(-120.0,-174.0),Dev(-145.0,-208.0),Dev(-145.0,-208.0),Dev(-145.0,-208.0),Dev(-170.0,-242.0),Dev(-170.0,-242.0),Dev(-170.0,-242.0),Dev(-190.0,-271.0),Dev(-190.0,-271.0),Dev(-210.0,-299.0),Dev(-210.0,-299.0),Dev(-230.0,-327.0),Dev(-230.0,-327.0)),
    "d9" to listOf(Dev(-20.0,-45.0),Dev(-30.0,-60.0),Dev(-40.0,-76.0),Dev(-50.0,-93.0),Dev(-50.0,-93.0),Dev(-65.0,-117.0),Dev(-65.0,-117.0),Dev(-80.0,-142.0),Dev(-80.0,-142.0),Dev(-100.0,-174.0),Dev(-100.0,-174.0),Dev(-120.0,-207.0),Dev(-120.0,-207.0),Dev(-145.0,-245.0),Dev(-145.0,-245.0),Dev(-145.0,-245.0),Dev(-170.0,-285.0),Dev(-170.0,-285.0),Dev(-170.0,-285.0),Dev(-190.0,-320.0),Dev(-190.0,-320.0),Dev(-210.0,-350.0),Dev(-210.0,-350.0),Dev(-230.0,-385.0),Dev(-230.0,-385.0)),
    "e7" to listOf(Dev(-14.0,-24.0),Dev(-20.0,-32.0),Dev(-25.0,-40.0),Dev(-32.0,-50.0),Dev(-32.0,-50.0),Dev(-40.0,-61.0),Dev(-40.0,-61.0),Dev(-50.0,-75.0),Dev(-50.0,-75.0),Dev(-60.0,-90.0),Dev(-60.0,-90.0),Dev(-72.0,-107.0),Dev(-72.0,-107.0),Dev(-85.0,-125.0),Dev(-85.0,-125.0),Dev(-85.0,-125.0),Dev(-100.0,-146.0),Dev(-100.0,-146.0),Dev(-100.0,-146.0),Dev(-110.0,-162.0),Dev(-110.0,-162.0),Dev(-125.0,-182.0),Dev(-125.0,-182.0),Dev(-135.0,-198.0),Dev(-135.0,-198.0)),
    "e8" to listOf(Dev(-14.0,-28.0),Dev(-20.0,-38.0),Dev(-25.0,-47.0),Dev(-32.0,-59.0),Dev(-32.0,-59.0),Dev(-40.0,-73.0),Dev(-40.0,-73.0),Dev(-50.0,-89.0),Dev(-50.0,-89.0),Dev(-60.0,-106.0),Dev(-60.0,-106.0),Dev(-72.0,-126.0),Dev(-72.0,-126.0),Dev(-85.0,-148.0),Dev(-85.0,-148.0),Dev(-85.0,-148.0),Dev(-100.0,-172.0),Dev(-100.0,-172.0),Dev(-100.0,-172.0),Dev(-110.0,-191.0),Dev(-110.0,-191.0),Dev(-125.0,-214.0),Dev(-125.0,-214.0),Dev(-135.0,-232.0),Dev(-135.0,-232.0)),
    "e9" to listOf(Dev(-14.0,-39.0),Dev(-20.0,-50.0),Dev(-25.0,-61.0),Dev(-32.0,-75.0),Dev(-32.0,-75.0),Dev(-40.0,-92.0),Dev(-40.0,-92.0),Dev(-50.0,-112.0),Dev(-50.0,-112.0),Dev(-60.0,-134.0),Dev(-60.0,-134.0),Dev(-72.0,-159.0),Dev(-72.0,-159.0),Dev(-85.0,-185.0),Dev(-85.0,-185.0),Dev(-85.0,-185.0),Dev(-100.0,-215.0),Dev(-100.0,-215.0),Dev(-100.0,-215.0),Dev(-110.0,-240.0),Dev(-110.0,-240.0),Dev(-125.0,-265.0),Dev(-125.0,-265.0),Dev(-135.0,-290.0),Dev(-135.0,-290.0)),
    "f6" to listOf(Dev(-6.0,-12.0),Dev(-10.0,-18.0),Dev(-13.0,-22.0),Dev(-16.0,-27.0),Dev(-16.0,-27.0),Dev(-20.0,-33.0),Dev(-20.0,-33.0),Dev(-25.0,-41.0),Dev(-25.0,-41.0),Dev(-30.0,-49.0),Dev(-30.0,-49.0),Dev(-36.0,-58.0),Dev(-36.0,-58.0),Dev(-43.0,-68.0),Dev(-43.0,-68.0),Dev(-43.0,-68.0),Dev(-50.0,-79.0),Dev(-50.0,-79.0),Dev(-50.0,-79.0),Dev(-56.0,-88.0),Dev(-56.0,-88.0),Dev(-62.0,-98.0),Dev(-62.0,-98.0),Dev(-68.0,-108.0),Dev(-68.0,-108.0)),
    "f7" to listOf(Dev(-6.0,-16.0),Dev(-10.0,-22.0),Dev(-13.0,-28.0),Dev(-16.0,-34.0),Dev(-16.0,-34.0),Dev(-20.0,-41.0),Dev(-20.0,-41.0),Dev(-25.0,-50.0),Dev(-25.0,-50.0),Dev(-30.0,-60.0),Dev(-30.0,-60.0),Dev(-36.0,-71.0),Dev(-36.0,-71.0),Dev(-43.0,-83.0),Dev(-43.0,-83.0),Dev(-43.0,-83.0),Dev(-50.0,-96.0),Dev(-50.0,-96.0),Dev(-50.0,-96.0),Dev(-56.0,-108.0),Dev(-56.0,-108.0),Dev(-62.0,-119.0),Dev(-62.0,-119.0),Dev(-68.0,-131.0),Dev(-68.0,-131.0)),
    "f8" to listOf(Dev(-6.0,-20.0),Dev(-10.0,-28.0),Dev(-13.0,-35.0),Dev(-16.0,-43.0),Dev(-16.0,-43.0),Dev(-20.0,-53.0),Dev(-20.0,-53.0),Dev(-25.0,-64.0),Dev(-25.0,-64.0),Dev(-30.0,-76.0),Dev(-30.0,-76.0),Dev(-36.0,-90.0),Dev(-36.0,-90.0),Dev(-43.0,-106.0),Dev(-43.0,-106.0),Dev(-43.0,-106.0),Dev(-50.0,-122.0),Dev(-50.0,-122.0),Dev(-50.0,-122.0),Dev(-56.0,-137.0),Dev(-56.0,-137.0),Dev(-62.0,-151.0),Dev(-62.0,-151.0),Dev(-68.0,-165.0),Dev(-68.0,-165.0)),
    "g5" to listOf(Dev(-2.0,-6.0),Dev(-4.0,-9.0),Dev(-5.0,-11.0),Dev(-6.0,-14.0),Dev(-6.0,-14.0),Dev(-7.0,-16.0),Dev(-7.0,-16.0),Dev(-9.0,-20.0),Dev(-9.0,-20.0),Dev(-10.0,-23.0),Dev(-10.0,-23.0),Dev(-12.0,-27.0),Dev(-12.0,-27.0),Dev(-14.0,-32.0),Dev(-14.0,-32.0),Dev(-14.0,-32.0),Dev(-15.0,-35.0),Dev(-15.0,-35.0),Dev(-15.0,-35.0),Dev(-17.0,-40.0),Dev(-17.0,-40.0),Dev(-18.0,-43.0),Dev(-18.0,-43.0),Dev(-20.0,-47.0),Dev(-20.0,-47.0)),
    "g6" to listOf(Dev(-2.0,-8.0),Dev(-4.0,-12.0),Dev(-5.0,-14.0),Dev(-6.0,-17.0),Dev(-6.0,-17.0),Dev(-7.0,-20.0),Dev(-7.0,-20.0),Dev(-9.0,-25.0),Dev(-9.0,-25.0),Dev(-10.0,-29.0),Dev(-10.0,-29.0),Dev(-12.0,-34.0),Dev(-12.0,-34.0),Dev(-14.0,-39.0),Dev(-14.0,-39.0),Dev(-14.0,-39.0),Dev(-15.0,-44.0),Dev(-15.0,-44.0),Dev(-15.0,-44.0),Dev(-17.0,-49.0),Dev(-17.0,-49.0),Dev(-18.0,-54.0),Dev(-18.0,-54.0),Dev(-20.0,-60.0),Dev(-20.0,-60.0)),
    "h5" to listOf(Dev(0.0,-4.0),Dev(0.0,-5.0),Dev(0.0,-6.0),Dev(0.0,-8.0),Dev(0.0,-8.0),Dev(0.0,-9.0),Dev(0.0,-9.0),Dev(0.0,-11.0),Dev(0.0,-11.0),Dev(0.0,-13.0),Dev(0.0,-13.0),Dev(0.0,-15.0),Dev(0.0,-15.0),Dev(0.0,-18.0),Dev(0.0,-18.0),Dev(0.0,-18.0),Dev(0.0,-20.0),Dev(0.0,-20.0),Dev(0.0,-20.0),Dev(0.0,-23.0),Dev(0.0,-23.0),Dev(0.0,-25.0),Dev(0.0,-25.0),Dev(0.0,-27.0),Dev(0.0,-27.0)),
    "h6" to listOf(Dev(0.0,-6.0),Dev(0.0,-8.0),Dev(0.0,-9.0),Dev(0.0,-11.0),Dev(0.0,-11.0),Dev(0.0,-13.0),Dev(0.0,-13.0),Dev(0.0,-16.0),Dev(0.0,-16.0),Dev(0.0,-19.0),Dev(0.0,-19.0),Dev(0.0,-22.0),Dev(0.0,-22.0),Dev(0.0,-25.0),Dev(0.0,-25.0),Dev(0.0,-25.0),Dev(0.0,-29.0),Dev(0.0,-29.0),Dev(0.0,-29.0),Dev(0.0,-32.0),Dev(0.0,-32.0),Dev(0.0,-36.0),Dev(0.0,-36.0),Dev(0.0,-40.0),Dev(0.0,-40.0)),
    "h7" to listOf(Dev(0.0,-10.0),Dev(0.0,-12.0),Dev(0.0,-15.0),Dev(0.0,-18.0),Dev(0.0,-18.0),Dev(0.0,-21.0),Dev(0.0,-21.0),Dev(0.0,-25.0),Dev(0.0,-25.0),Dev(0.0,-30.0),Dev(0.0,-30.0),Dev(0.0,-35.0),Dev(0.0,-35.0),Dev(0.0,-40.0),Dev(0.0,-40.0),Dev(0.0,-40.0),Dev(0.0,-46.0),Dev(0.0,-46.0),Dev(0.0,-46.0),Dev(0.0,-52.0),Dev(0.0,-52.0),Dev(0.0,-57.0),Dev(0.0,-57.0),Dev(0.0,-63.0),Dev(0.0,-63.0)),
    "h8" to listOf(Dev(0.0,-14.0),Dev(0.0,-18.0),Dev(0.0,-22.0),Dev(0.0,-27.0),Dev(0.0,-27.0),Dev(0.0,-33.0),Dev(0.0,-33.0),Dev(0.0,-39.0),Dev(0.0,-39.0),Dev(0.0,-46.0),Dev(0.0,-46.0),Dev(0.0,-54.0),Dev(0.0,-54.0),Dev(0.0,-63.0),Dev(0.0,-63.0),Dev(0.0,-63.0),Dev(0.0,-72.0),Dev(0.0,-72.0),Dev(0.0,-72.0),Dev(0.0,-81.0),Dev(0.0,-81.0),Dev(0.0,-89.0),Dev(0.0,-89.0),Dev(0.0,-97.0),Dev(0.0,-97.0)),
    "h9" to listOf(Dev(0.0,-25.0),Dev(0.0,-30.0),Dev(0.0,-36.0),Dev(0.0,-43.0),Dev(0.0,-43.0),Dev(0.0,-52.0),Dev(0.0,-52.0),Dev(0.0,-62.0),Dev(0.0,-62.0),Dev(0.0,-74.0),Dev(0.0,-74.0),Dev(0.0,-87.0),Dev(0.0,-87.0),Dev(0.0,-100.0),Dev(0.0,-100.0),Dev(0.0,-100.0),Dev(0.0,-115.0),Dev(0.0,-115.0),Dev(0.0,-115.0),Dev(0.0,-130.0),Dev(0.0,-130.0),Dev(0.0,-140.0),Dev(0.0,-140.0),Dev(0.0,-155.0),Dev(0.0,-155.0)),
    "js5" to listOf(Dev(2.0,-2.0),Dev(2.5,-2.5),Dev(3.0,-3.0),Dev(4.0,-4.0),Dev(4.0,-4.0),Dev(4.5,-4.5),Dev(4.5,-4.5),Dev(5.5,-5.5),Dev(5.5,-5.5),Dev(6.5,-6.5),Dev(6.5,-6.5),Dev(7.5,-7.5),Dev(7.5,-7.5),Dev(9.0,-9.0),Dev(9.0,-9.0),Dev(9.0,-9.0),Dev(10.0,-10.0),Dev(10.0,-10.0),Dev(10.0,-10.0),Dev(11.5,-11.5),Dev(11.5,-11.5),Dev(12.5,-12.5),Dev(12.5,-12.5),Dev(13.5,-13.5),Dev(13.5,-13.5)),
    "js6" to listOf(Dev(3.0,-3.0),Dev(4.0,-4.0),Dev(4.5,-4.5),Dev(5.5,-5.5),Dev(5.5,-5.5),Dev(6.5,-6.5),Dev(6.5,-6.5),Dev(8.0,-8.0),Dev(8.0,-8.0),Dev(9.5,-9.5),Dev(9.5,-9.5),Dev(11.0,-11.0),Dev(11.0,-11.0),Dev(12.5,-12.5),Dev(12.5,-12.5),Dev(12.5,-12.5),Dev(14.5,-14.5),Dev(14.5,-14.5),Dev(14.5,-14.5),Dev(16.0,-16.0),Dev(16.0,-16.0),Dev(18.0,-18.0),Dev(18.0,-18.0),Dev(20.0,-20.0),Dev(20.0,-20.0)),
    "js7" to listOf(Dev(5.0,-5.0),Dev(6.0,-6.0),Dev(7.0,-7.0),Dev(9.0,-9.0),Dev(9.0,-9.0),Dev(10.0,-10.0),Dev(10.0,-10.0),Dev(12.0,-12.0),Dev(12.0,-12.0),Dev(15.0,-15.0),Dev(15.0,-15.0),Dev(17.0,-17.0),Dev(17.0,-17.0),Dev(20.0,-20.0),Dev(20.0,-20.0),Dev(20.0,-20.0),Dev(23.0,-23.0),Dev(23.0,-23.0),Dev(23.0,-23.0),Dev(26.0,-26.0),Dev(26.0,-26.0),Dev(28.0,-28.0),Dev(28.0,-28.0),Dev(31.0,-31.0),Dev(31.0,-31.0)),
    "k5" to listOf(Dev(4.0,0.0),Dev(6.0,1.0),Dev(7.0,1.0),Dev(9.0,1.0),Dev(9.0,1.0),Dev(11.0,2.0),Dev(11.0,2.0),Dev(13.0,2.0),Dev(13.0,2.0),Dev(15.0,2.0),Dev(15.0,2.0),Dev(18.0,3.0),Dev(18.0,3.0),Dev(21.0,3.0),Dev(21.0,3.0),Dev(21.0,3.0),Dev(24.0,4.0),Dev(24.0,4.0),Dev(24.0,4.0),Dev(27.0,4.0),Dev(27.0,4.0),Dev(29.0,4.0),Dev(29.0,4.0),Dev(32.0,5.0),Dev(32.0,5.0)),
    "k6" to listOf(Dev(6.0,0.0),Dev(9.0,1.0),Dev(10.0,1.0),Dev(12.0,1.0),Dev(12.0,1.0),Dev(15.0,2.0),Dev(15.0,2.0),Dev(18.0,2.0),Dev(18.0,2.0),Dev(21.0,2.0),Dev(21.0,2.0),Dev(25.0,3.0),Dev(25.0,3.0),Dev(28.0,3.0),Dev(28.0,3.0),Dev(28.0,3.0),Dev(33.0,4.0),Dev(33.0,4.0),Dev(33.0,4.0),Dev(36.0,4.0),Dev(36.0,4.0),Dev(40.0,4.0),Dev(40.0,4.0),Dev(45.0,5.0),Dev(45.0,5.0)),
    "m5" to listOf(Dev(6.0,2.0),Dev(9.0,4.0),Dev(12.0,6.0),Dev(15.0,7.0),Dev(15.0,7.0),Dev(17.0,8.0),Dev(17.0,8.0),Dev(20.0,9.0),Dev(20.0,9.0),Dev(24.0,11.0),Dev(24.0,11.0),Dev(28.0,13.0),Dev(28.0,13.0),Dev(33.0,15.0),Dev(33.0,15.0),Dev(33.0,15.0),Dev(37.0,17.0),Dev(37.0,17.0),Dev(37.0,17.0),Dev(43.0,20.0),Dev(43.0,20.0),Dev(46.0,21.0),Dev(46.0,21.0),Dev(50.0,23.0),Dev(50.0,23.0)),
    "m6" to listOf(Dev(8.0,2.0),Dev(12.0,4.0),Dev(15.0,6.0),Dev(18.0,7.0),Dev(18.0,7.0),Dev(21.0,8.0),Dev(21.0,8.0),Dev(25.0,9.0),Dev(25.0,9.0),Dev(30.0,11.0),Dev(30.0,11.0),Dev(35.0,13.0),Dev(35.0,13.0),Dev(40.0,15.0),Dev(40.0,15.0),Dev(40.0,15.0),Dev(46.0,17.0),Dev(46.0,17.0),Dev(46.0,17.0),Dev(52.0,20.0),Dev(52.0,20.0),Dev(57.0,21.0),Dev(57.0,21.0),Dev(63.0,23.0),Dev(63.0,23.0)),
    "n6" to listOf(Dev(10.0,4.0),Dev(16.0,8.0),Dev(19.0,10.0),Dev(23.0,12.0),Dev(23.0,12.0),Dev(28.0,15.0),Dev(28.0,15.0),Dev(33.0,17.0),Dev(33.0,17.0),Dev(39.0,20.0),Dev(39.0,20.0),Dev(45.0,23.0),Dev(45.0,23.0),Dev(52.0,27.0),Dev(52.0,27.0),Dev(52.0,27.0),Dev(60.0,31.0),Dev(60.0,31.0),Dev(60.0,31.0),Dev(66.0,34.0),Dev(66.0,34.0),Dev(73.0,37.0),Dev(73.0,37.0),Dev(80.0,40.0),Dev(80.0,40.0)),
    "p6" to listOf(Dev(12.0,6.0),Dev(20.0,12.0),Dev(24.0,15.0),Dev(29.0,18.0),Dev(29.0,18.0),Dev(35.0,22.0),Dev(35.0,22.0),Dev(42.0,26.0),Dev(42.0,26.0),Dev(51.0,32.0),Dev(51.0,32.0),Dev(59.0,37.0),Dev(59.0,37.0),Dev(68.0,43.0),Dev(68.0,43.0),Dev(68.0,43.0),Dev(79.0,50.0),Dev(79.0,50.0),Dev(79.0,50.0),Dev(88.0,56.0),Dev(88.0,56.0),Dev(98.0,62.0),Dev(98.0,62.0),Dev(108.0,68.0),Dev(108.0,68.0)),
    "r6" to listOf(Dev(16.0,10.0),Dev(23.0,15.0),Dev(28.0,19.0),Dev(34.0,23.0),Dev(34.0,23.0),Dev(41.0,28.0),Dev(41.0,28.0),Dev(50.0,34.0),Dev(50.0,34.0),Dev(60.0,41.0),Dev(62.0,43.0),Dev(73.0,51.0),Dev(76.0,54.0),Dev(88.0,63.0),Dev(90.0,65.0),Dev(93.0,68.0),Dev(106.0,77.0),Dev(109.0,80.0),Dev(113.0,84.0),Dev(126.0,94.0),Dev(130.0,98.0),Dev(144.0,108.0),Dev(150.0,114.0),Dev(166.0,126.0),Dev(172.0,132.0)),
    "s6" to listOf(Dev(20.0,14.0),Dev(27.0,19.0),Dev(32.0,23.0),Dev(39.0,28.0),Dev(39.0,28.0),Dev(48.0,35.0),Dev(48.0,35.0),Dev(59.0,43.0),Dev(59.0,43.0),Dev(72.0,53.0),Dev(78.0,59.0),Dev(93.0,71.0),Dev(101.0,79.0),Dev(117.0,92.0),Dev(125.0,100.0),Dev(133.0,108.0),Dev(151.0,122.0),Dev(159.0,130.0),Dev(169.0,140.0),null,null,null,null,null,null),
    "t6" to listOf(null,null,null,null,null,null,Dev(54.0,41.0),Dev(64.0,48.0),Dev(70.0,54.0),Dev(85.0,66.0),Dev(94.0,75.0),Dev(113.0,91.0),Dev(126.0,104.0),Dev(147.0,122.0),Dev(159.0,134.0),Dev(171.0,146.0),null,null,null,null,null,null,null,null,null),
    "u6" to listOf(Dev(24.0,18.0),Dev(31.0,23.0),Dev(37.0,28.0),Dev(44.0,33.0),Dev(44.0,33.0),Dev(54.0,41.0),Dev(61.0,48.0),Dev(76.0,60.0),Dev(86.0,70.0),Dev(106.0,87.0),Dev(121.0,102.0),Dev(146.0,124.0),Dev(166.0,144.0),null,null,null,null,null,null,null,null,null,null,null,null),
    "x6" to listOf(Dev(26.0,20.0),Dev(36.0,28.0),Dev(43.0,34.0),Dev(51.0,40.0),Dev(56.0,45.0),Dev(67.0,54.0),Dev(77.0,64.0),null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
)

object MetricToleranceMath {
    fun availableCallouts(diameterMm:Double,hole:Boolean):List<String>{
        val idx=sizeIndex(diameterMm) ?: return emptyList()
        val table=if(hole) HOLE_TOL else SHAFT_TOL
        return table.entries.filter { it.value.getOrNull(idx) != null }.map { it.key }.sortedWith(String.CASE_INSENSITIVE_ORDER)
    }
    fun lookup(diameterMm:Double,callout:String,hole:Boolean):CalcResult<ToleranceResult>{
        val idx=sizeIndex(diameterMm) ?: return CalcResult(error=CalcError("Diameter must be between 1 and 500 mm for this reference table."))
        val key=callout.trim()
        if(hole && key!=key.uppercase()) return CalcResult(error=CalcError("Hole callouts use an uppercase letter, for example H7 or N7."))
        if(!hole && key!=key.lowercase()) return CalcResult(error=CalcError("Shaft callouts use a lowercase letter, for example h7 or n7."))
        val dev=if(hole)HOLE_TOL[key]?.get(idx) else SHAFT_TOL[key]?.get(idx)
            ?: return CalcResult(error=CalcError("That tolerance callout is not in the on-device reference data."))
        if(dev==null)return CalcResult(error=CalcError("That tolerance is not specified for this diameter range."))
        val upper=dev.upperUm/1000.0; val lower=dev.lowerUm/1000.0
        return CalcResult(value=ToleranceResult(dev.upperUm,dev.lowerUm,upper,lower,diameterMm+upper,diameterMm+lower))
    }
}

data class Csink(val size:String,val diameter:Double,val unit:String)
object CountersinkMath {
    private val metric=listOf("M3" to 7.72,"M4" to 9.96,"M5" to 12.20,"M6" to 14.44,"M8" to 18.92,"M10" to 23.40,"M12" to 27.88,"M14" to 31.24,"M16" to 34.60,"M18" to 37.96,"M20" to 41.32)
    private val inch=listOf("#0" to .149,"#1" to .183,"#2" to .217,"#3" to .247,"#4" to .280,"#5" to .310,"#6" to .339,"#8" to .389,"#10" to .442,"1/4" to .561,"5/16" to .688,"3/8" to .812,"7/16" to .876,"1/2" to .967,"5/8" to 1.219,"3/4" to 1.469,"7/8" to 1.720,"1" to 1.970,"1 1/8" to 2.312,"1 1/4" to 2.499,"1 3/8" to 2.751,"1 1/2" to 3.000)
    fun lookup(size:String,isMetric:Boolean):CalcResult<Csink>{
        val list=if(isMetric)metric else inch; val hit=list.firstOrNull{it.first.equals(size.trim(),true)} ?: return CalcResult(error=CalcError("Screw size is not in the reference table."))
        return CalcResult(value=Csink(hit.first,hit.second,if(isMetric)"mm" else "in"))
    }
    fun rows(isMetric:Boolean):List<Pair<String,Double>> = if(isMetric)metric else inch
}

object HardnessMath {
    fun lookup(scale:String,value:Double):CalcResult<HardnessResult>{
        if(!value.isFinite())return CalcResult(error=CalcError("Enter a valid hardness value."))
        val key=scale.uppercase()
        val row=when(key){
            "HRC"->HARDNESS.minByOrNull{abs((it.hrc?:1e99)-value)}?.takeIf{it.hrc!=null && abs(it.hrc-value)<=1e-9}
            "HB"->HARDNESS.minByOrNull{abs((it.hb?:1e99)-value)}?.takeIf{it.hb!=null && abs(it.hb-value)<=1e-9}
            "HRB"->HARDNESS.minByOrNull{abs((it.hrb?:1e99)-value)}?.takeIf{it.hrb!=null && abs(it.hrb-value)<=1e-9}
            "HRA"->HARDNESS.minByOrNull{abs((it.hra?:1e99)-value)}?.takeIf{it.hra!=null && abs(it.hra-value)<=1e-9}
            else->null
        } ?: return CalcResult(error=CalcError("That hardness value is not an exact point in the on-device reference table."))
        return CalcResult(value=HardnessResult(row.hb,row.hra,row.hrb,row.hrc,row.tensilePsi))
    }
    fun rows():List<Hard> = HARDNESS
}
private val HARDNESS = listOf(
    Hard(331.0,68.0,null,36.0,166000.0),
    Hard(321.0,68.0,null,34.0,160000.0),
    Hard(311.0,67.0,null,33.0,155000.0),
    Hard(302.0,66.0,null,32.0,150000.0),
    Hard(293.0,66.0,null,31.0,145000.0),
    Hard(285.0,65.0,null,30.0,141000.0),
    Hard(277.0,65.0,null,29.0,137000.0),
    Hard(269.0,64.0,null,28.0,133000.0),
    Hard(262.0,64.0,null,27.0,129000.0),
    Hard(255.0,63.0,null,25.0,126000.0),
    Hard(248.0,62.0,null,24.0,122000.0),
    Hard(241.0,62.0,100.0,23.0,118000.0),
    Hard(235.0,61.0,99.0,22.0,115000.0),
    Hard(229.0,61.0,98.0,20.0,111000.0),
    Hard(223.0,null,97.0,20.0,null),
    Hard(217.0,null,96.0,18.0,105000.0),
    Hard(212.0,null,96.0,17.0,102000.0),
    Hard(207.0,null,95.0,16.0,100000.0),
    Hard(201.0,null,94.0,15.0,98000.0),
    Hard(197.0,null,93.0,null,95000.0),
    Hard(192.0,null,92.0,null,93000.0),
    Hard(187.0,null,91.0,null,90000.0),
    Hard(183.0,null,90.0,null,89000.0),
    Hard(179.0,null,89.0,null,87000.0),
    Hard(174.0,null,88.0,null,85000.0),
    Hard(170.0,null,87.0,null,83000.0),
    Hard(167.0,null,86.0,null,81000.0),
    Hard(163.0,null,85.0,null,79000.0),
    Hard(156.0,null,83.0,null,76000.0),
    Hard(149.0,null,81.0,null,73000.0),
    Hard(143.0,null,79.0,null,71000.0),
    Hard(137.0,null,76.0,null,67000.0),
    Hard(131.0,null,74.0,null,65000.0),
    Hard(126.0,null,72.0,null,63000.0),
    Hard(121.0,null,70.0,null,60000.0),
    Hard(116.0,null,68.0,null,58000.0),
    Hard(111.0,null,66.0,null,56000.0)
)
