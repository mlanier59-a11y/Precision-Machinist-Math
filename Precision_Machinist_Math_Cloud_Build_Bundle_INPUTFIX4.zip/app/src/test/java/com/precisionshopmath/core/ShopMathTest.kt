package com.precisionshopmath.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ShopMathTest {
    private fun near(a:Double,b:Double,t:Double=1e-9)=assertTrue("$a != $b",abs(a-b)<=t)

    @Test fun threePinWorkbookExample(){near(ThreePinMath.boreDiameter(.9728,.9718,.9038).value!!,2.048033612,1e-9)}
    @Test fun threePinEstimatorIsExactBeforeDisplayRounding(){val e=ThreePinMath.estimatePins(2.0475).value!!;near(ThreePinMath.boreDiameter(e.pin1,e.pin2,e.pin3).value!!,2.0475,1e-10)}
    @Test fun triangleWorkbookExample(){val r=TriangleMath.solve(aDeg=3.43363036245053,y=.7675).value!!;near(r.x,12.79166667,1e-7);near(r.r,12.81467098,1e-7);near(r.bDeg,86.56636963754947,1e-10)}
    @Test fun triangleAllNinePairs(){
        val cases=listOf(
            TriangleMath.solve(aDeg=30.0,x=5.0),TriangleMath.solve(aDeg=30.0,y=2.886751345948129),TriangleMath.solve(aDeg=30.0,r=5.773502691896258),
            TriangleMath.solve(bDeg=60.0,x=5.0),TriangleMath.solve(bDeg=60.0,y=2.886751345948129),TriangleMath.solve(bDeg=60.0,r=5.773502691896258),
            TriangleMath.solve(x=5.0,y=2.886751345948129),TriangleMath.solve(x=5.0,r=5.773502691896258),TriangleMath.solve(y=2.886751345948129,r=5.773502691896258))
        cases.forEach{assertTrue(it.ok);val v=it.value!!;near(v.aDeg,30.0,1e-9);near(v.x,5.0,1e-8);near(v.y,2.886751345948129,1e-8);near(v.r,5.773502691896258,1e-8)}
    }
    @Test fun sineBar(){near(SineBarMath.stackHeight(30.0,5.0).value!!,2.5,1e-12);near(SineBarMath.stackHeight(12.5,5.0).value!!,1.0821980696905145,1e-12)}
    @Test fun sineBarDms(){near(SineBarMath.dmsToDecimal(12.0,30.0,0.0).value!!,12.5,1e-12)}
    @Test fun metricAndInchThread(){near(ThreadMath.metricTapDrill(10.0,1.5,75.0).value!!,8.53858,1e-9);near(ThreadMath.inchTapDrill(.375,32.0,75.0).value!!,.34455375,1e-12);near(ThreadMath.inchPercent(.375,32.0,.34455375).value!!,75.0,1e-9)}
    @Test fun metricToleranceExamples(){val h=MetricToleranceMath.lookup(12.0,"H7",true).value!!;assertEquals(18.0,h.upperUm,0.0);assertEquals(0.0,h.lowerUm,0.0);val n=MetricToleranceMath.lookup(36.0,"N7",true).value!!;assertEquals(-8.0,n.upperUm,0.0);assertEquals(-33.0,n.lowerUm,0.0);val s=MetricToleranceMath.lookup(12.0,"h7",false).value!!;assertEquals(0.0,s.upperUm,0.0);assertEquals(-18.0,s.lowerUm,0.0)}
    @Test fun countersinkExamples(){assertEquals(14.44,CountersinkMath.lookup("M6",true).value!!.diameter,0.0);assertEquals(.442,CountersinkMath.lookup("#10",false).value!!.diameter,0.0)}
    @Test fun hardnessExample(){val r=HardnessMath.lookup("HRC",36.0).value!!;assertEquals(331.0,r.hb!!,0.0);assertEquals(166000.0,r.tensilePsi!!,0.0)}
    @Test fun dmsTwelveThirty(){val a=SineBarMath.dmsToDecimal(12.0,30.0,0.0).value!!;assertEquals(12.5,a,1e-12);assertEquals(1.082197832,a.let{SineBarMath.stackHeight(it,5.0).value!!},1e-9)}
}
