Upload this ZIP to the repository root and set the workflow unzip command to:

unzip -q Precision_Machinist_Math_Cloud_Build_Bundle_INPUTFIX7.zip -d project
