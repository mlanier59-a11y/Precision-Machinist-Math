package com.precisionshopmath

import android.content.Context
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.precisionshopmath.core.*
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PrecisionMachinistMathApp() } }
}

private fun fmt(v:Double, places:Int=5)=String.format(Locale.US,"%.${places}f",v)
private fun num(s:String)=s.toDoubleOrNull()
private fun buzz(ctx:Context){ try{ (ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(VibrationEffect.createOneShot(100,VibrationEffect.DEFAULT_AMPLITUDE)) }catch(_:Throwable){} }

@Composable private fun ErrorBox(message:String?) {
    if(message!=null) Surface(color=MaterialTheme.colorScheme.error,modifier=Modifier.fillMaxWidth().padding(bottom=10.dp)) {
        Text("⚠  $message",Modifier.padding(12.dp),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onError,textAlign=TextAlign.Center)
    }
}

@Composable private fun Header(title:String,back:()->Unit){
    Text(title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,modifier=Modifier.fillMaxWidth().padding(bottom=10.dp),textAlign=TextAlign.Center)
}

@Composable private fun HomeButton(home:()->Unit){ OutlinedButton(onClick=home,modifier=Modifier.fillMaxWidth()){Text("HOME",fontWeight=FontWeight.Bold)} }

@Composable private fun NumField(label:String,value:String,onValue:(String)->Unit,modifier:Modifier=Modifier.fillMaxWidth(),enabled:Boolean=true){
    OutlinedTextField(
        value=value,
        onValueChange=onValue,
        label={Text(label)},
        singleLine=true,
        enabled=enabled,
        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),
        modifier=modifier
    )
}

@Composable private fun BigChoice(label:String,selected:Boolean,onClick:()->Unit,modifier:Modifier=Modifier){
    OutlinedButton(onClick=onClick,modifier=modifier.height(58.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=if(selected)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)){
        Text(if(selected)"●  $label" else "○  $label",fontWeight=FontWeight.Bold)
    }
}

@Composable private fun ThreePinGraphic(){
    val line=MaterialTheme.colorScheme.onSurface
    val pin=MaterialTheme.colorScheme.primaryContainer
    val pinLine=MaterialTheme.colorScheme.primary
    Column(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Text("THREE-PIN CONTACT GEOMETRY",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelLarge)
        Box(Modifier.fillMaxWidth().height(190.dp)){
            Canvas(Modifier.fillMaxSize()){
                val c=Offset(size.width/2f,size.height/2f+4f)
                val boreR=minOf(size.width*0.29f,size.height*0.43f)
                drawCircle(line,boreR,c,style=Stroke(width=4f))
                val pr=boreR*0.43f
                val p1=Offset(c.x,c.y-boreR*0.43f)
                val p2=Offset(c.x-boreR*0.39f,c.y+boreR*0.27f)
                val p3=Offset(c.x+boreR*0.39f,c.y+boreR*0.27f)
                listOf(p1,p2,p3).forEach{pt->drawCircle(pin,pr,pt);drawCircle(pinLine,pr,pt,style=Stroke(width=3f))}
            }
            Text("1",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.TopCenter).padding(top=39.dp))
            Text("2",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.BottomCenter).offset(x=(-42).dp,y=(-36).dp))
            Text("3",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.BottomCenter).offset(x=42.dp,y=(-36).dp))
            Text("BORE",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelMedium,modifier=Modifier.align(Alignment.CenterEnd).padding(end=18.dp))
        }
    }
}

@Composable private fun RightTriangleGraphic(){
    val line=MaterialTheme.colorScheme.onSurface
    Column(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.fillMaxWidth().height(190.dp)){
            Canvas(Modifier.fillMaxSize().padding(horizontal=42.dp,vertical=18.dp)){
                val left=Offset(0f,size.height)
                val right=Offset(size.width,size.height)
                val top=Offset(size.width,0f)
                drawLine(line,left,right,strokeWidth=4f)
                drawLine(line,right,top,strokeWidth=4f)
                drawLine(line,top,left,strokeWidth=4f)
                val m=16f
                drawLine(line,Offset(right.x-m,right.y),Offset(right.x-m,right.y-m),strokeWidth=3f)
                drawLine(line,Offset(right.x-m,right.y-m),Offset(right.x,right.y-m),strokeWidth=3f)
            }
            Text("R",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.Center).offset(x=(-24).dp,y=(-16).dp))
            Text("X",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.BottomCenter).padding(bottom=2.dp))
            Text("Y",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.CenterEnd).padding(end=18.dp))
            Text("A",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.BottomStart).padding(start=24.dp,bottom=12.dp))
            Text("B",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.TopEnd).padding(end=24.dp,top=10.dp))
        }
    }
}

@Composable private fun SineBarGraphic(){
    val line=MaterialTheme.colorScheme.onSurface
    val accent=MaterialTheme.colorScheme.primary
    val fill=MaterialTheme.colorScheme.primaryContainer
    Column(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.fillMaxWidth().height(180.dp)){
            Canvas(Modifier.fillMaxSize().padding(horizontal=24.dp,vertical=16.dp)){
                val yBase=size.height*0.84f
                drawLine(line,Offset(0f,yBase),Offset(size.width,yBase),strokeWidth=4f)
                val left=Offset(size.width*0.16f,yBase-18f)
                val right=Offset(size.width*0.80f,size.height*0.34f)
                drawLine(accent,left,right,strokeWidth=14f)
                drawCircle(fill,18f,left);drawCircle(line,18f,left,style=Stroke(width=3f))
                drawCircle(fill,18f,right);drawCircle(line,18f,right,style=Stroke(width=3f))
                val stackX=right.x-20f
                var y=yBase
                repeat(5){i->
                    val h=(yBase-right.y-20f)/5f
                    drawRect(if(i%2==0) fill else accent.copy(alpha=0.22f),topLeft=Offset(stackX,y-h),size=androidx.compose.ui.geometry.Size(40f,h-2f))
                    y-=h
                }
                drawLine(line,Offset(size.width*0.12f,yBase-4f),Offset(size.width*0.26f,yBase-4f),strokeWidth=2f)
                drawLine(line,Offset(size.width*0.12f,yBase-4f),Offset(size.width*0.25f,yBase-38f),strokeWidth=2f)
            }
            Text("ANGLE",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelMedium,modifier=Modifier.align(Alignment.BottomStart).padding(start=28.dp,bottom=18.dp))
            Text("SINE BAR LENGTH (C-C)",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelMedium,modifier=Modifier.align(Alignment.TopCenter).padding(top=4.dp))
            Text("GAGE
BLOCKS",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelMedium,textAlign=TextAlign.Center,modifier=Modifier.align(Alignment.CenterEnd).padding(end=4.dp,top=44.dp))
        }
    }
}

@Composable private fun PrecisionMachinistMathApp(){
    var screen by remember{mutableStateOf("menu")}
    BackHandler(enabled=screen!="menu"){screen="menu"}
    MaterialTheme{
        Surface(Modifier.fillMaxSize()){
            when(screen){
                "menu"->MainMenu{screen=it}; "three"->ThreePinScreen{screen="menu"}; "thread"->ThreadScreen{screen="menu"};
                "triangle"->TriangleScreen{screen="menu"}; "sine"->SineBarScreen{screen="menu"}; "fits"->FitsScreen{screen="menu"};
                "csink"->CountersinkScreen{screen="menu"}; "hardness"->HardnessScreen{screen="menu"}
            }
        }
    }
}

@Composable private fun MainMenu(go:(String)->Unit){
    Column(Modifier.fillMaxSize().padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Text("PRECISION MACHINIST MATH",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text("Machinist's pocket calculator",style=MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))
        Button({go("three")},Modifier.fillMaxWidth().height(74.dp)){Text("THREE-PIN BORE",fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({go("thread")},Modifier.weight(1f).height(60.dp)){Text("THREAD CALC")};Button({go("triangle")},Modifier.weight(1f).height(60.dp)){Text("RIGHT TRIANGLE")}}
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({go("sine")},Modifier.weight(1f).height(60.dp)){Text("SINE BAR")};Button({go("fits")},Modifier.weight(1f).height(60.dp)){Text("METRIC FITS")}}
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({go("csink")},Modifier.weight(1f).height(60.dp)){Text("COUNTERSINK")};Button({go("hardness")},Modifier.weight(1f).height(60.dp)){Text("HARDNESS")}}
    }
}

@Composable private fun ThreePinScreen(back:()->Unit){
    val ctx=LocalContext.current
    var target by remember{mutableStateOf("")};var p1 by remember{mutableStateOf("")};var p2 by remember{mutableStateOf("")};var p3 by remember{mutableStateOf("")};var est by remember{mutableStateOf<ThreePinEstimate?>(null)};var result by remember{mutableStateOf<Double?>(null)};var error by remember{mutableStateOf<String?>(null)};var buzzed by remember{mutableStateOf(false)}
    fun fail(m:String){error=m;if(!buzzed){buzz(ctx);buzzed=true}}
    fun clear(){target="";p1="";p2="";p3="";est=null;result=null;error=null;buzzed=false}
    Column(Modifier.fillMaxSize().background(if(error!=null) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState()).padding(12.dp)){Header("THREE-PIN BORE",back);ErrorBox(error);ThreePinGraphic()
        Text("1. ESTIMATE PINS",fontWeight=FontWeight.Bold);NumField("Bore diameter",target,{target=it})
        Button({try{val q=ThreePinMath.estimatePins(num(target)?:Double.NaN);if(q.ok&&q.value!=null){est=q.value;error=null;buzzed=false}else{est=null;fail(q.error?.message ?: "Enter a valid bore diameter.")}}catch(_:Throwable){est=null;fail("Enter a valid bore diameter.")}},Modifier.fillMaxWidth()){Text("ESTIMATE PINS")}
        est?.let{Column(Modifier.fillMaxWidth().padding(vertical=8.dp)){Text("Suggested pin diameters",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Pin 1" to it.pin1,"Pin 2" to it.pin2,"Pin 3" to it.pin3).forEach{(n,v)->OutlinedTextField(value=fmt(v,3),onValueChange={},readOnly=true,label={Text(n)},modifier=Modifier.weight(1f))}}}}
        Spacer(Modifier.height(10.dp));Text("2. ACTUAL PIN DIAMETERS",fontWeight=FontWeight.Bold)
        NumField("Pin 1",p1,{p1=it});NumField("Pin 2",p2,{p2=it});NumField("Pin 3",p3,{p3=it})
        Button({try{val q=ThreePinMath.boreDiameter(num(p1)?:Double.NaN,num(p2)?:Double.NaN,num(p3)?:Double.NaN);if(q.ok&&q.value!=null){result=q.value;error=null;buzzed=false}else{result=null;fail(q.error?.message ?: "Pin combination cannot form a valid bore.")}}catch(_:Throwable){result=null;fail("Pin combination cannot form a valid bore.")}},Modifier.fillMaxWidth()){Text("CALCULATE BORE")}
        result?.let{Text("BORE DIAMETER   ${fmt(it)}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=10.dp))}
        OutlinedButton({clear()},Modifier.fillMaxWidth()){Text("CLEAR")};HomeButton(back)
    }
}

@Composable private fun TriangleScreen(back:()->Unit){
    val ctx=LocalContext.current;val focus=LocalFocusManager.current
    var a by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var x by remember{mutableStateOf("")};var y by remember{mutableStateOf("")};var r by remember{mutableStateOf("")};var out by remember{mutableStateOf<TriangleResult?>(null)};var err by remember{mutableStateOf<String?>(null)};var buzzed by remember{mutableStateOf(false)}
    fun fail(m:String){err=m;if(!buzzed){buzz(ctx);buzzed=true}}
    fun setA(v:String){a=v;out=null;err=null;val n=num(v);b=if(n!=null&&n>0&&n<90) fmt(90.0-n,5) else ""}
    fun setB(v:String){b=v;out=null;err=null;val n=num(v);a=if(n!=null&&n>0&&n<90) fmt(90.0-n,5) else ""}
    Column(Modifier.fillMaxSize().background(if(err!=null) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState()).padding(12.dp)){Header("RIGHT TRIANGLE",back);RightTriangleGraphic()
        Surface(color=if(err!=null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.surface,modifier=Modifier.fillMaxWidth().padding(vertical=8.dp)) {
            Text("Enter one angle and one side\nOr two sides",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,color=if(err!=null) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onSurface,modifier=Modifier.fillMaxWidth().padding(10.dp))
        }
        NumField("A — degrees",a,{setA(it)});NumField("B — degrees",b,{setB(it)});NumField("X",x,{x=it;out=null;err=null});NumField("Y",y,{y=it;out=null;err=null});NumField("R — hypotenuse",r,{r=it;out=null;err=null})
        Button({
            focus.clearFocus()
            try{
                val av=num(a);val bv=num(b);val xv=num(x);val yv=num(y);val rv=num(r);val sides=listOf(xv,yv,rv).count{it!=null}
                val q=when{
                    av!=null && (av<=0||av>=90) -> CalcResult<TriangleResult>(error=CalcError("Angle A must be greater than 0° and less than 90°."))
                    bv!=null && (bv<=0||bv>=90) -> CalcResult<TriangleResult>(error=CalcError("Angle B must be greater than 0° and less than 90°."))
                    av!=null && bv!=null && kotlin.math.abs(av+bv-90.0)>1e-4 -> CalcResult<TriangleResult>(error=CalcError("Angles A and B must total 90°."))
                    av!=null && sides==1 -> TriangleMath.solve(av,null,xv,yv,rv)
                    av==null && bv!=null && sides==1 -> TriangleMath.solve(null,bv,xv,yv,rv)
                    av==null && bv==null && sides==2 -> TriangleMath.solve(null,null,xv,yv,rv)
                    else -> CalcResult<TriangleResult>(error=CalcError("Enter one angle and one side or two sides."))
                }
                if(q.ok && q.value!=null){out=q.value;err=null;buzzed=false}else{out=null;fail(q.error?.message ?: "Those values do not form a valid right triangle.")}
            }catch(_:Throwable){out=null;fail("Those values do not form a valid right triangle.")}
        },Modifier.fillMaxWidth()){Text("CALCULATE")}
        out?.let{Column(Modifier.padding(vertical=8.dp)){Text("CALCULATED VALUES",fontWeight=FontWeight.Bold);Text("A  ${fmt(it.aDeg)}°");Text("B  ${fmt(it.bDeg)}°");Text("X  ${fmt(it.x)}");Text("Y  ${fmt(it.y)}");Text("R  ${fmt(it.r)}",fontWeight=FontWeight.Bold)}}
        OutlinedButton({a="";b="";x="";y="";r="";out=null;err=null;buzzed=false},Modifier.fillMaxWidth()){Text("CLEAR")};HomeButton(back)
    }
}

@Composable private fun SineBarScreen(back:()->Unit){
    val ctx=LocalContext.current;val prefs=ctx.getSharedPreferences("pm",0);var metric by remember{mutableStateOf(prefs.getBoolean("sineMetric",false))};var angleMode by remember{mutableStateOf(false)};var angle by remember{mutableStateOf("")};var deg by remember{mutableStateOf("")};var min by remember{mutableStateOf("")};var sec by remember{mutableStateOf("")};var length by remember{mutableStateOf("5")};var out by remember{mutableStateOf<Double?>(null)};var err by remember{mutableStateOf<String?>(null)};var buzzed by remember{mutableStateOf(false)}
    fun fail(m:String){err=m;if(!buzzed){buzz(ctx);buzzed=true}}
    Column(Modifier.fillMaxSize().background(if(err!=null) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState()).padding(12.dp)){Header("SINE BAR",back);ErrorBox(err);SineBarGraphic();Text("GAGE BLOCK STACK",fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){BigChoice("INCH",!metric,{metric=false;prefs.edit().putBoolean("sineMetric",false).apply()},Modifier.weight(1f));BigChoice("METRIC",metric,{metric=true;prefs.edit().putBoolean("sineMetric",true).apply()},Modifier.weight(1f))}
        Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){BigChoice("DECIMAL DEGREES",!angleMode,{angleMode=false},Modifier.weight(1f));BigChoice("DMS",angleMode,{angleMode=true},Modifier.weight(1f))}
        if(!angleMode)NumField("ANGLE (degrees)",angle,{thisAngle->angle=thisAngle}) else Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){NumField("Degrees",deg,{deg=it},Modifier.weight(1f));NumField("Minutes",min,{min=it},Modifier.weight(1f));NumField("Seconds",sec,{sec=it},Modifier.weight(1f))}
        NumField("SINE BAR LENGTH (${if(metric)"mm" else "in"})",length,{length=it});Text("Length is the roller center-to-center distance.",style=MaterialTheme.typography.bodySmall)
        Button({
            val angleValue = if(angleMode){
                val d=num(deg); val m=num(min); val s=num(sec)
                if(d==null || m==null || s==null || d<0.0 || m<0.0 || m>=60.0 || s<0.0 || s>=60.0){
                    null
                } else d + m/60.0 + s/3600.0
            } else num(angle)
            if(angleValue==null || angleValue<=0.0 || angleValue>=90.0){out=null;fail("Enter valid angle between 0° and 90°.")}
            else {
                val q=SineBarMath.stackHeight(angleValue,num(length)?:Double.NaN)
                if(q.ok&&q.value!=null){out=q.value;err=null;buzzed=false}else{out=null;fail(if(angleValue<=0.0 || angleValue>=90.0) "Enter valid angle between 0° and 90°." else (q.error?.message ?: "Invalid input."))}
            }
        },Modifier.fillMaxWidth()){Text("CALCULATE STACK")}
        out?.let{Text("GAGE BLOCK STACK   ${fmt(it)} ${if(metric)"mm" else "in"}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=10.dp))}
        OutlinedButton({angle="";deg="";min="";sec="";length="5";out=null;err=null;buzzed=false},Modifier.fillMaxWidth()){Text("CLEAR")};HomeButton(back)
    }
}

@Composable private fun ThreadScreen(back:()->Unit){
    val ctx=LocalContext.current;val prefs=ctx.getSharedPreferences("pm",0);var metric by remember{mutableStateOf(prefs.getBoolean("threadMetric",false))};var percentMode by remember{mutableStateOf(false)};var od by remember{mutableStateOf("")};var pitch by remember{mutableStateOf("")};var pct by remember{mutableStateOf(if(metric)"76.98" else "75.00")};var hole by remember{mutableStateOf("")};var out by remember{mutableStateOf<Double?>(null)};var err by remember{mutableStateOf<String?>(null)};var buzzed by remember{mutableStateOf(false)}
    fun fail(m:String){err=m;if(!buzzed){buzz(ctx);buzzed=true}}
    fun setMetric(v:Boolean){metric=v;prefs.edit().putBoolean("threadMetric",v).apply();pct=if(v)"76.98" else "75.00";out=null;err=null}
    Column(Modifier.fillMaxSize().background(if(err!=null) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState()).padding(12.dp)){Header("THREAD CALCULATOR",back);ErrorBox(err);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){BigChoice("INCH",!metric,{setMetric(false)},Modifier.weight(1f));BigChoice("METRIC",metric,{setMetric(true)},Modifier.weight(1f))}
        Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){BigChoice("TAP DRILL FROM THREAD",!percentMode,{percentMode=false},Modifier.weight(1f));BigChoice("THREAD % FROM DRILLED HOLE",percentMode,{percentMode=true},Modifier.weight(1f))}
        NumField("MAJOR DIAMETER (${if(metric)"mm" else "in"})",od,{od=it});NumField(if(metric)"PITCH (mm)" else "THREADS PER INCH (TPI)",pitch,{pitch=it})
        if(percentMode)NumField("DRILLED HOLE DIAMETER (${if(metric)"mm" else "in"})",hole,{hole=it})
        Button({val q=if(percentMode){if(metric)ThreadMath.metricPercent(num(od)?:Double.NaN,num(pitch)?:Double.NaN,num(hole)?:Double.NaN) else ThreadMath.inchPercent(num(od)?:Double.NaN,num(pitch)?:Double.NaN,num(hole)?:Double.NaN)}else{if(metric)ThreadMath.metricTapDrill(num(od)?:Double.NaN,num(pitch)?:Double.NaN,num(pct)?:Double.NaN) else ThreadMath.inchTapDrill(num(od)?:Double.NaN,num(pitch)?:Double.NaN,num(pct)?:Double.NaN)};if(q.ok&&q.value!=null){out=q.value;err=null;buzzed=false}else{out=null;fail(q.error?.message ?: "Invalid input.")}},Modifier.fillMaxWidth()){Text("CALCULATE")}
        out?.let{Text(if(percentMode)"${fmt(it,2)}% Full Thread" else "TAP DRILL   ${fmt(it,4)} ${if(metric)"mm" else "in"}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(vertical=10.dp))}
        Text("Conventional 60° thread calculation. Check against the applicable thread standard/tooling practice.",style=MaterialTheme.typography.bodySmall)
        OutlinedButton({od="";pitch="";hole="";pct=if(metric)"76.98" else "75.00";out=null;err=null;buzzed=false},Modifier.fillMaxWidth()){Text("CLEAR")};HomeButton(back)
    }
}

@Composable private fun FitsScreen(back:()->Unit){
    val ctx=LocalContext.current;var hole by remember{mutableStateOf(true)};var dia by remember{mutableStateOf("")};var callout by remember{mutableStateOf("H7")};var out by remember{mutableStateOf<ToleranceResult?>(null)};var err by remember{mutableStateOf<String?>(null)};var buzzed by remember{mutableStateOf(false)};var expanded by remember{mutableStateOf(false)}
    fun fail(m:String){err=m;if(!buzzed){buzz(ctx);buzzed=true}}
    val d=num(dia);val choices=if(d!=null) MetricToleranceMath.availableCallouts(d,hole) else emptyList()
    LaunchedEffect(dia,hole){if(choices.isNotEmpty() && callout !in choices) callout=choices.first()}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Header("METRIC FITS / TOLERANCES",back);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){BigChoice("HOLE",hole,{hole=true;callout="H7";out=null;err=null},Modifier.weight(1f));BigChoice("SHAFT",!hole,{hole=false;callout="h7";out=null;err=null},Modifier.weight(1f))}
        NumField("NOMINAL DIAMETER (mm)",dia,{dia=it;out=null;err=null})
        Box(Modifier.fillMaxWidth()){OutlinedButton(onClick={if(choices.isNotEmpty())expanded=true},modifier=Modifier.fillMaxWidth(),enabled=choices.isNotEmpty()){Text(if(choices.isEmpty()) "ENTER DIAMETER TO SELECT TOLERANCE" else "TOLERANCE CALLOUT   $callout",style=MaterialTheme.typography.titleMedium,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())};DropdownMenu(expanded=expanded,onDismissRequest={expanded=false},modifier=Modifier.fillMaxWidth(.92f)){choices.forEach{c->DropdownMenuItem(text={Text(c,style=MaterialTheme.typography.titleLarge,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())},onClick={callout=c;expanded=false;out=null;err=null})}}}
        Button({val q=MetricToleranceMath.lookup(num(dia)?:Double.NaN,callout,hole);if(q.ok&&q.value!=null){out=q.value;err=null;buzzed=false}else{out=null;fail(q.error?.message ?: "Invalid input.")}},Modifier.fillMaxWidth(),enabled=choices.isNotEmpty()){Text("CALCULATE")};ErrorBox(err)
        out?.let{Column(Modifier.fillMaxWidth().padding(vertical=10.dp)){Text(if(hole)"HOLE TOLERANCE ($callout)" else "SHAFT TOLERANCE ($callout)",fontWeight=FontWeight.Bold);Text("Upper deviation: ${signed(it.upperUm)} µm   (${signed5(it.upperMm)} mm)");Text("Lower deviation: ${signed(it.lowerUm)} µm   (${signed5(it.lowerMm)} mm)");Text("Upper limit: ${fmt(it.upperLimitMm)} mm");Text("Lower limit: ${fmt(it.lowerLimitMm)} mm",fontWeight=FontWeight.Bold)}}
        Text("Reference data from the supplied ISO-style tolerance workbook. Use the applicable current ISO 286 standard for production acceptance.",style=MaterialTheme.typography.bodySmall);OutlinedButton({dia="";callout=if(hole)"H7" else "h7";out=null;err=null;buzzed=false},Modifier.fillMaxWidth()){Text("CLEAR")};HomeButton(back)
    }
}
private fun signed(v:Double)=if(v>=0)"+${fmt(v,0)}" else fmt(v,0)
private fun signed5(v:Double)=if(v>=0)"+${fmt(v)}" else fmt(v)

@Composable private fun CountersinkScreen(back:()->Unit){
    var metric by remember{mutableStateOf(true)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Header("COUNTERSINK REFERENCE",back);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){BigChoice("METRIC 90°",metric,{metric=true},Modifier.weight(1f));BigChoice("INCH 82°",!metric,{metric=false},Modifier.weight(1f))}
        Text(if(metric)"90° flat-head screw — 0.5 mm below flush" else "82° flat-head screw — 0.020 in below flush",fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=10.dp))
        Row(Modifier.fillMaxWidth(.82f).align(Alignment.CenterHorizontally).padding(vertical=6.dp)){Text("BOLT SIZE",fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,modifier=Modifier.weight(1f));Text("C'SINK DIA.",fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,modifier=Modifier.weight(1f))}
        HorizontalDivider(Modifier.fillMaxWidth(.82f).align(Alignment.CenterHorizontally))
        CountersinkMath.rows(metric).forEachIndexed{i,row->
            val rowModifier=Modifier.fillMaxWidth(.82f).align(Alignment.CenterHorizontally)
            if(i%2==1) Surface(color=MaterialTheme.colorScheme.surfaceVariant,modifier=rowModifier){Row(Modifier.fillMaxWidth().padding(vertical=7.dp)){Text(row.first,textAlign=TextAlign.Center,modifier=Modifier.weight(1f));Text(if(metric)fmt(row.second,2)+" mm ("+fmt(row.second/25.4,3)+"\")" else fmt(row.second,3)+" in",textAlign=TextAlign.Center,modifier=Modifier.weight(1f))}}
            else Row(rowModifier.padding(vertical=7.dp)){Text(row.first,textAlign=TextAlign.Center,modifier=Modifier.weight(1f));Text(if(metric)fmt(row.second,2)+" mm ("+fmt(row.second/25.4,3)+"\")" else fmt(row.second,3)+" in",textAlign=TextAlign.Center,modifier=Modifier.weight(1f))}
        }
        Spacer(Modifier.height(10.dp));HomeButton(back)
    }
}

@Composable private fun HardnessScreen(back:()->Unit){
    val ctx=LocalContext.current;var scale by remember{mutableStateOf("HRC")};var value by remember{mutableStateOf("")};var out by remember{mutableStateOf<HardnessResult?>(null)};var err by remember{mutableStateOf<String?>(null)};var buzzed by remember{mutableStateOf(false)}
    fun fail(m:String){err=m;if(!buzzed){buzz(ctx);buzzed=true}}
    Column(Modifier.fillMaxSize().background(if(err!=null) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState()).padding(12.dp)){Header("HARDNESS REFERENCE",back);ErrorBox(err);Column(verticalArrangement=Arrangement.spacedBy(6.dp)){listOf(listOf("HRC" to "Rockwell/c","HB" to "Brinell"),listOf("HRB" to "Rockwell/b","HRA" to "Rockwell/a")).forEach{pair->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){pair.forEach{(s,label)->BigChoice(label,scale==s,{scale=s;out=null;err=null},Modifier.weight(1f))}}}}
        NumField("$scale VALUE",value,{value=it});Button({
            val v=num(value)
            val range=HardnessMath.inputRange(scale)
            val label=when(scale){"HRC"->"Rockwell C";"HRB"->"Rockwell B";"HRA"->"Rockwell A";else->"Brinell"}
            if(v==null || range==null || v<range.first || v>range.second){out=null;fail("$label input range: ${fmt(range?.first ?: 0.0,0)} to ${fmt(range?.second ?: 0.0,0)}.")}
            else {val q=HardnessMath.lookup(scale,v);if(q.ok&&q.value!=null){out=q.value;err=null;buzzed=false}else{out=null;fail("$label input range: ${fmt(range.first,0)} to ${fmt(range.second,0)}. Enter a value contained in the reference table.")}}
        },Modifier.fillMaxWidth()){Text("LOOK UP")}
        out?.let{Column(Modifier.padding(vertical=10.dp)){Text("APPROXIMATE CONVERSIONS",fontWeight=FontWeight.Bold);it.hb?.let{v->Text("Brinell (HB): ${fmt(v,0)}")};it.hra?.let{v->Text("Rockwell A: ${fmt(v,0)}")};it.hrb?.let{v->Text("Rockwell B: ${fmt(v,0)}")};it.hrc?.let{v->Text("Rockwell C: ${fmt(v,0)}")}}}
        Text("Reference only\nHardness conversions are approximate and material-dependent.\nNot a suitable substitute for a hardness test.",fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(vertical=8.dp));OutlinedButton({value="";out=null;err=null;buzzed=false},Modifier.fillMaxWidth()){Text("CLEAR")};HomeButton(back)
    }
}
