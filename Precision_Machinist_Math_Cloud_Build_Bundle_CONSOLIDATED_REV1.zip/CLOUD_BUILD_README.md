Cloud build bundle: CONSOLIDATED_REV1
Unzip this ZIP to project/ in the GitHub Actions workflow, then run the existing Gradle test/build steps.
