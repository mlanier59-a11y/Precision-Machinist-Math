Cloud build bundle: INPUTFIX7B
Unzip this ZIP to project/ in the GitHub Actions workflow, then run the existing Gradle test/build steps.
