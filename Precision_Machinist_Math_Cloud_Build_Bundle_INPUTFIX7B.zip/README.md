Precision Machinist Math — INPUTFIX7B

Graphics refinement build based on INPUTFIX7A.
- Three-pin vector geometry now uses mutually tangent pins tangent to bore.
- Right-triangle graphic reduced about 20%% and A/B/X/Y/R labels enlarged.
- Sine-bar graphic removes redundant ANGLE and C-C labels/guide lines and moves GAGE BLOCKS beside the stack.
