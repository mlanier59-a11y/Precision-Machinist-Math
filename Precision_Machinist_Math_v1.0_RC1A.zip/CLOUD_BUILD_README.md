Cloud build bundle: Precision Machinist Math v1.0 RC1A

This bundle is frozen from the live-device validated CONSOLIDATED_REV1B baseline.

Android versionName: 1.0.0-rc1a
Android versionCode: 2

Unzip this ZIP to project/ in the existing GitHub Actions workflow, then run the same Gradle test/build steps used for REV1B.

No calculator logic, machining formulas, reference values, or validated UI behavior were intentionally changed for RC1A. This package changes release/version metadata and documentation only.


RC1A change: Metric Fits result labels and values are separated onto intentional centered lines to prevent narrow-phone word wrapping. No calculation logic changed.
