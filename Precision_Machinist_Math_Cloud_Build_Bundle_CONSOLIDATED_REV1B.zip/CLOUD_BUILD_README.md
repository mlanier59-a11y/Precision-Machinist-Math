Cloud build bundle: CONSOLIDATED_REV1B

Unzip this ZIP to project/ in the GitHub Actions workflow, then run the existing Gradle test/build steps.

This revision is a UI/input cleanup based on live device testing of REV1A. Core calculation logic is unchanged.
