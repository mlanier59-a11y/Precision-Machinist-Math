import com.precisionshopmath.core.*
import kotlin.math.abs
fun chk(name:String,a:Double,b:Double,t:Double=1e-8){require(abs(a-b)<=t){"$name $a != $b"};println("PASS $name: $a")}
fun main(){
 chk("three-pin workbook",ThreePinMath.boreDiameter(.9728,.9718,.9038).value!!,2.048033612,1e-9)
 val e=ThreePinMath.estimatePins(2.0475).value!!; chk("three-pin estimator",ThreePinMath.boreDiameter(e.pin1,e.pin2,e.pin3).value!!,2.0475,1e-9)
 val t=TriangleMath.solve(aDeg=3.43363036245053,y=.7675).value!!; chk("triangle X",t.x,12.79166667,1e-7);chk("triangle R",t.r,12.81467098,1e-7)
 chk("sine bar",SineBarMath.stackHeight(30.0,5.0).value!!,2.5,1e-12)
 chk("metric tap",ThreadMath.metricTapDrill(10.0,1.5,75.0).value!!,8.53858,1e-12)
 chk("inch tap",ThreadMath.inchTapDrill(.375,32.0,75.0).value!!,.34455375,1e-12)
 println("ALL CORE SMOKE TESTS PASSED")
}
