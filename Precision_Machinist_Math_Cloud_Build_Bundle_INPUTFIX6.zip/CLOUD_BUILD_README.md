# Cloud Build — INPUTFIX6
Upload `Precision_Machinist_Math_Cloud_Build_Bundle_INPUTFIX6.zip` to the repository root and set the workflow unzip step to that exact filename. Run `gradle test` before assembling the debug APK.
