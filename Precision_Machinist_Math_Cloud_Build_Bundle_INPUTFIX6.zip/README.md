# Precision Machinist Math — INPUTFIX6
Hardening build: controlled invalid-input errors, HOME navigation, rotation state preservation, thread result formatting, triangle complementary-angle entry, metric countersink inch equivalents, and portrait-safe hardness controls. Calculation methods that passed INPUTFIX5 testing are unchanged.
