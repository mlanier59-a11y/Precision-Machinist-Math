package com.precisionshopmath

import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.precisionshopmath.core.*
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PrecisionShopMathApp() } }
}

@Composable fun PrecisionShopMathApp() {
    var screen by remember { mutableStateOf("menu") }
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            when(screen) {
                "menu" -> MainMenu { screen=it }
                "three" -> ThreePinScreen { screen="menu" }
                "triangle" -> TriangleScreen { screen="menu" }
                "sine" -> SineBarScreen { screen="menu" }
                "thread" -> ThreadScreen { screen="menu" }
                "fits" -> ReferenceScreen("METRIC FITS / TOLERANCES") { screen="menu" }
                "csink" -> ReferenceScreen("COUNTERSINK REFERENCE") { screen="menu" }
                "hardness" -> ReferenceScreen("HARDNESS REFERENCE") { screen="menu" }
            }
        }
    }
}

@Composable private fun Header(title:String, back:()->Unit) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically) { TextButton(onClick=back){Text("‹ BACK")}; Text(title, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold) } }

@Composable private fun MainMenu(go:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("PRECISION SHOP MATH", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(24.dp)); Button(onClick={go("three")}, modifier=Modifier.fillMaxWidth().height(72.dp)){Text("THREE-PIN BORE")}
        Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({go("thread")},Modifier.weight(1f)){Text("THREAD CALC")};Button({go("triangle")},Modifier.weight(1f)){Text("RIGHT TRIANGLE")}}
        Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({go("sine")},Modifier.weight(1f)){Text("SINE BAR")};Button({go("fits")},Modifier.weight(1f)){Text("METRIC FITS")}}
        Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)){Button({go("csink")},Modifier.weight(1f)){Text("COUNTERSINK")};Button({go("hardness")},Modifier.weight(1f)){Text("HARDNESS")}}
    }
}

@Composable private fun NumField(label:String, value:String, modifier:Modifier=Modifier.fillMaxWidth(), onValue:(String)->Unit) { OutlinedTextField(value,onValue,label={Text(label)},singleLine=true,modifier=modifier) }
private fun d(s:String)=s.toDoubleOrNull()
private fun fmt(v:Double)=String.format(Locale.US,"%.5f",v)

@Composable private fun ErrorBox(message:String?) { if(message!=null) Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.errorContainer),modifier=Modifier.fillMaxWidth().padding(vertical=8.dp)){Text(message,Modifier.padding(12.dp),color=MaterialTheme.colorScheme.onErrorContainer)} }

@Composable private fun ThreePinScreen(back:()->Unit) {
    val ctx=LocalContext.current; var target by remember{mutableStateOf("")}; var p1 by remember{mutableStateOf("")};var p2 by remember{mutableStateOf("")};var p3 by remember{mutableStateOf("")};var est by remember{mutableStateOf<ThreePinEstimate?>(null)};var result by remember{mutableStateOf<Double?>(null)};var error by remember{mutableStateOf<String?>(null)};var errored by remember{mutableStateOf(false)}
    fun fail(m:String){error=m;if(!errored){(ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(VibrationEffect.createOneShot(100,VibrationEffect.DEFAULT_AMPLITUDE));errored=true}}
    fun clear(){target="";p1="";p2="";p3="";est=null;result=null;error=null;errored=false}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Header("THREE-PIN BORE",back);Text("Target / blueprint bore",fontWeight=FontWeight.Bold);NumField("Bore diameter",target){target=it};Button({val r=ThreePinMath.estimatePins(d(target)?:Double.NaN);if(r.ok){est=r.value;error=null;errored=false}else fail(r.error!!.message)},Modifier.fillMaxWidth()){Text("ESTIMATE PINS")};est?.let{Text("Suggested pins: ${fmt(it.pin1)}, ${fmt(it.pin2)}, ${fmt(it.pin3)}",fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));Text("ACTUAL PIN DIAMETERS",fontWeight=FontWeight.Bold);NumField("Pin 1",p1){p1=it};NumField("Pin 2",p2){p2=it};NumField("Pin 3",p3){p3=it};Button({val r=ThreePinMath.boreDiameter(d(p1)?:Double.NaN,d(p2)?:Double.NaN,d(p3)?:Double.NaN);if(r.ok){result=r.value;error=null;errored=false}else fail(r.error!!.message)},Modifier.fillMaxWidth()){Text("CALCULATE BORE")};ErrorBox(error);result?.let{Text("BORE DIAMETER  ${fmt(it)}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(8.dp));OutlinedButton(::clear,Modifier.fillMaxWidth()){Text("CLEAR")}}
}

@Composable private fun TriangleScreen(back:()->Unit){var a by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var x by remember{mutableStateOf("")};var y by remember{mutableStateOf("")};var r by remember{mutableStateOf("")};var out by remember{mutableStateOf<TriangleResult?>(null)};var err by remember{mutableStateOf<String?>(null)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Header("RIGHT TRIANGLE",back);Text("Enter exactly two known values. Other fields are solved.");NumField("A — degrees",a){a=it};NumField("B — degrees",b){b=it};NumField("X",x){x=it};NumField("Y",y){y=it};NumField("R — hypotenuse",r){r=it};Button({val q=TriangleMath.solve(d(a),d(b),d(x),d(y),d(r));if(q.ok){out=q.value;err=null}else{out=null;err=q.error!!.message}},Modifier.fillMaxWidth()){Text("CALCULATE")};ErrorBox(err);out?.let{Column{Text("A  ${fmt(it.aDeg)}°");Text("B  ${fmt(it.bDeg)}°");Text("X  ${fmt(it.x)}");Text("Y  ${fmt(it.y)}");Text("R  ${fmt(it.r)}",fontWeight=FontWeight.Bold)}};OutlinedButton({a="";b="";x="";y="";r="";out=null;err=null},Modifier.fillMaxWidth()){Text("CLEAR")}}
}

@Composable private fun SineBarScreen(back:()->Unit){var angle by remember{mutableStateOf("")};var length by remember{mutableStateOf("5")};var out by remember{mutableStateOf<Double?>(null)};var err by remember{mutableStateOf<String?>(null)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Header("SINE BAR",back);Text("Angle is decimal degrees in beta 1.",fontWeight=FontWeight.Bold);NumField("ANGLE",angle){angle=it};NumField("SINE BAR LENGTH",length){length=it};Button({val q=SineBarMath.stackHeight(d(angle)?:Double.NaN,d(length)?:Double.NaN);if(q.ok){out=q.value;err=null}else{out=null;err=q.error!!.message}},Modifier.fillMaxWidth()){Text("CALCULATE STACK")};ErrorBox(err);out?.let{Text("GAGE BLOCK STACK  ${fmt(it)}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};OutlinedButton({angle="";length="5";out=null;err=null},Modifier.fillMaxWidth()){Text("CLEAR")}}
}

@Composable private fun ThreadScreen(back:()->Unit){var metric by remember{mutableStateOf(true)};var od by remember{mutableStateOf("")};var pitch by remember{mutableStateOf("")};var pct by remember{mutableStateOf("75")};var hole by remember{mutableStateOf("")};var out by remember{mutableStateOf<Double?>(null)};var err by remember{mutableStateOf<String?>(null)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Header("THREAD CALCULATOR",back);Row(verticalAlignment=Alignment.CenterVertically){Text("METRIC");Switch(metric,{metric=it});Text("INCH")};NumField("MAJOR DIAMETER",od){od=it};NumField(if(metric)"PITCH (mm)" else "THREADS PER INCH",pitch){pitch=it};NumField("% FULL THREAD",pct){pct=it};Button({val q=if(metric)ThreadMath.metricTapDrill(d(od)?:Double.NaN,d(pitch)?:Double.NaN,d(pct)?:Double.NaN) else ThreadMath.inchTapDrill(d(od)?:Double.NaN,d(pitch)?:Double.NaN,d(pct)?:Double.NaN);if(q.ok){out=q.value;err=null}else{out=null;err=q.error!!.message}},Modifier.fillMaxWidth()){Text("CALCULATE TAP DRILL")};ErrorBox(err);out?.let{Text("THEORETICAL TAP DRILL  ${fmt(it)}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)};OutlinedButton({od="";pitch="";pct="75";out=null;err=null},Modifier.fillMaxWidth()){Text("CLEAR")}}
}

@Composable private fun ReferenceScreen(title:String,back:()->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Header(title,back);Text("REFERENCE DATA",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text("The beta keeps reference data on-device and removes the Excel workbook from the user experience. The final reference tables will be populated from the verified workbook/standard datasets during the next data-build pass.");Spacer(Modifier.height(20.dp));Text("No calculation is performed on this screen.")}}
