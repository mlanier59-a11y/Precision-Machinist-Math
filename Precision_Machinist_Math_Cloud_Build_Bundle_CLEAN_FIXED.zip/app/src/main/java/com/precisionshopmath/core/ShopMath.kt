package com.precisionshopmath.core

import kotlin.math.*

enum class UnitSystem { INCH, METRIC }

data class ThreePinEstimate(val pin1: Double, val pin2: Double, val pin3: Double)

data class TriangleResult(val aDeg: Double, val bDeg: Double, val x: Double, val y: Double, val r: Double)

data class CalcError(val message: String)

data class CalcResult<T>(val value: T? = null, val error: CalcError? = null) { val ok get() = error == null }

object ThreePinMath {
    /** Descartes circle theorem. Pins are external tangent circles; bore is the inner tangent circle. */
    fun boreDiameter(pin1: Double, pin2: Double, pin3: Double): CalcResult<Double> {
        if (!pin1.isFinite() || !pin2.isFinite() || !pin3.isFinite() || pin1 <= 0 || pin2 <= 0 || pin3 <= 0)
            return CalcResult(error = CalcError("All three pin diameters must be greater than zero."))
        val k1 = 2.0 / pin1; val k2 = 2.0 / pin2; val k3 = 2.0 / pin3
        val rad = k1*k2 + k1*k3 + k2*k3
        if (rad <= 0.0 || !rad.isFinite()) return CalcResult(error = CalcError("Pin combination cannot form a valid bore."))
        val kb = k1 + k2 + k3 - 2.0*sqrt(rad)
        if (kb >= 0.0 || !kb.isFinite()) return CalcResult(error = CalcError("These pins cannot fit as three contacting pins in a bore."))
        return CalcResult(value = -2.0 / kb)
    }

    /** Exact starting-pin estimate based on the workbook's first two-pin strategy, choosing the larger valid third pin. */
    fun estimatePins(targetBore: Double): CalcResult<ThreePinEstimate> {
        if (!targetBore.isFinite() || targetBore <= 0.0)
            return CalcResult(error = CalcError("Target bore diameter must be greater than zero."))
        val p1 = targetBore * 0.475
        val delta = min(0.001, targetBore * 0.0005)
        val p2 = p1 - delta
        if (p2 <= 0.0) return CalcResult(error = CalcError("Target bore is too small for a practical pin estimate."))
        val k1 = 2.0/p1; val k2 = 2.0/p2; val targetK = -2.0/targetBore; val s = k1+k2
        // Squaring the Descartes equation gives a quadratic. Two positive roots exist; the larger pin is the useful shop starting point.
        val b = -2.0*(s + targetK)
        val c = (s-targetK)*(s-targetK) - 4.0*k1*k2
        val disc = b*b - 4.0*c
        if (disc <= 0.0 || !disc.isFinite()) return CalcResult(error = CalcError("No valid three-pin estimate exists for this bore size."))
        val t1 = (-b + sqrt(disc))/2.0
        val t2 = (-b - sqrt(disc))/2.0
        val candidates = listOf(t1,t2).filter { it > 0 && it.isFinite() }.map { 2.0/it }.sortedDescending()
        if (candidates.isEmpty()) return CalcResult(error = CalcError("No valid third-pin estimate exists."))
        return CalcResult(value = ThreePinEstimate(p1,p2,candidates.first()))
    }
}

object TriangleMath {
    fun solve(aDeg: Double? = null, bDeg: Double? = null, x: Double? = null, y: Double? = null, r: Double? = null): CalcResult<TriangleResult> {
        val values = listOf(aDeg,bDeg,x,y,r)
        if (values.any { it != null && (!it.isFinite() || it <= 0.0) }) return CalcResult(error=CalcError("All entered values must be greater than zero."))
        val known = values.count { it != null }
        if (known != 2) return CalcResult(error=CalcError("Enter exactly two dimensions or angles."))
        val A: Double; val B: Double; val X: Double; val Y: Double; val R: Double
        when {
            aDeg != null && x != null -> { A=aDeg; X=x; B=90-A; Y=X*tan(Math.toRadians(A)); R=X/cos(Math.toRadians(A)) }
            aDeg != null && y != null -> { A=aDeg; Y=y; B=90-A; X=Y/tan(Math.toRadians(A)); R=Y/sin(Math.toRadians(A)) }
            aDeg != null && r != null -> { A=aDeg; R=r; B=90-A; X=R*cos(Math.toRadians(A)); Y=R*sin(Math.toRadians(A)) }
            bDeg != null && x != null -> { B=bDeg; X=x; A=90-B; Y=X/tan(Math.toRadians(B)); R=X/sin(Math.toRadians(B)) }
            bDeg != null && y != null -> { B=bDeg; Y=y; A=90-B; X=Y*tan(Math.toRadians(B)); R=Y/cos(Math.toRadians(B)) }
            bDeg != null && r != null -> { B=bDeg; R=r; A=90-B; X=R*sin(Math.toRadians(B)); Y=R*cos(Math.toRadians(B)) }
            x != null && y != null -> { X=x; Y=y; R=hypot(X,Y); A=Math.toDegrees(atan2(Y,X)); B=90-A }
            x != null && r != null -> { X=x; R=r; if (X>=R) return CalcResult(error=CalcError("Side X must be smaller than hypotenuse R.")); Y=sqrt(R*R-X*X); A=Math.toDegrees(acos(X/R)); B=90-A }
            y != null && r != null -> { Y=y; R=r; if (Y>=R) return CalcResult(error=CalcError("Side Y must be smaller than hypotenuse R.")); X=sqrt(R*R-Y*Y); A=Math.toDegrees(asin(Y/R)); B=90-A }
            else -> return CalcResult(error=CalcError("That pair is not a valid right-triangle input combination."))
        }
        if (A <= 0 || B <= 0 || A >= 90 || B >= 90 || X <= 0 || Y <= 0 || R <= 0 || !listOf(A,B,X,Y,R).all { it.isFinite() })
            return CalcResult(error=CalcError("Those values do not form a valid right triangle."))
        return CalcResult(value=TriangleResult(A,B,X,Y,R))
    }
}

object SineBarMath {
    fun stackHeight(angleDeg: Double, length: Double): CalcResult<Double> {
        if (!angleDeg.isFinite() || angleDeg <= 0 || angleDeg >= 90) return CalcResult(error=CalcError("Angle must be greater than 0° and less than 90°."))
        if (!length.isFinite() || length <= 0) return CalcResult(error=CalcError("Sine bar length must be greater than zero."))
        return CalcResult(value=length*sin(Math.toRadians(angleDeg)))
    }
}

object ThreadMath {
    private const val K60 = 1.29904
    fun metricTapDrill(majorMm: Double, pitchMm: Double, percent: Double): CalcResult<Double> {
        if (majorMm<=0 || pitchMm<=0 || percent<=0 || percent>100) return CalcResult(error=CalcError("Enter a valid major diameter, pitch, and thread percentage."))
        return CalcResult(value=majorMm - (percent/100.0)*K60*pitchMm)
    }
    fun metricPercent(majorMm: Double, pitchMm: Double, drillMm: Double): CalcResult<Double> {
        if (majorMm<=0 || pitchMm<=0 || drillMm<=0 || drillMm>=majorMm) return CalcResult(error=CalcError("Enter a valid major diameter, pitch, and drilled diameter."))
        return CalcResult(value=((majorMm-drillMm)/(K60*pitchMm))*100.0)
    }
    fun inchTapDrill(majorIn: Double, tpi: Double, percent: Double): CalcResult<Double> {
        if (majorIn<=0 || tpi<=0 || percent<=0 || percent>100) return CalcResult(error=CalcError("Enter a valid major diameter, TPI, and thread percentage."))
        return CalcResult(value=majorIn - (percent/100.0)*K60/tpi)
    }
    fun inchPercent(majorIn: Double, tpi: Double, drillIn: Double): CalcResult<Double> {
        if (majorIn<=0 || tpi<=0 || drillIn<=0 || drillIn>=majorIn) return CalcResult(error=CalcError("Enter a valid major diameter, TPI, and drilled diameter."))
        return CalcResult(value=(majorIn-drillIn)*tpi/K60*100.0)
    }
}
