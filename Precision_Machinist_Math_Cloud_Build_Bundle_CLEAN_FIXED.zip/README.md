# Precision Machinist Math — Android Beta 0.1.0-beta1

Working-tool beta foundation for an offline machinist/toolmaker pocket reference. The Excel workbook is treated as a source/reference only; it is **not** included in the app architecture.

## Important second-pass findings

1. The `.375` / `32 pitch` entries on the Metric Thread sheet are treated as accidental/bogus saved values and are **not** carried into the app as defaults.
2. A deeper review caught an important orientation issue in the earlier triangle specification. The workbook's example `A = 3.43363036245053°`, `Y = .7675` produces `X ≈ 12.79166667`, so **X is adjacent to A and Y is opposite A**. The beta math engine has been corrected to match the workbook geometry.
3. The three-pin estimator has been improved: instead of the workbook's empirical `0.882860071` constant, beta solves the Descartes equation for the larger physically useful third-pin root. The displayed suggested pins will still be rounded for shop use; the bore calculation always uses the actual measured pin diameters.
4. Thread calculations use the conventional 60° thread relationship with `1.29904` as the working constant. No intermediate rounding is performed.
5. Core smoke tests pass for the workbook three-pin example, triangle example, sine-bar example, and metric/inch tap-drill math.

## Current beta contents

- Main menu with the requested large centered Three-Pin Bore button and paired secondary buttons.
- Three-Pin Bore calculation engine and initial UI.
- Right Triangle calculation engine and initial UI.
- Sine Bar calculation engine and initial UI.
- Metric/inch thread tap-drill calculation engine and initial UI.
- Reference-screen placeholders for Metric Fits, Countersink, and Hardness.
- Error-state architecture: concise error message, red error container, and one-shot haptic transition in the Three-Pin screen. The production UI should apply the same transition behavior to every calculator.

## Locked UI requirements for the next beta pass

- Fixed physical orientation for the five triangle diagrams, with embedded input fields and inactive fields greyed out after a valid pair is established.
- Full sine-bar graphic as previously approved. No generic C-to-C indication and no dimension lines tied to a nominal 5.0000 length. The length input itself is the only length specification.
- Sine bar supports decimal degrees and DMS input; default length 5.00000 and remembered last unit.
- Five-place displayed dimensions; three-pin suggested pins 3 places, actual pins 4 places, bore 5 places.
- No Excel workbook in the user-facing app.
- No Shop Reference section.
- Offline operation and remembered last unit selection.

## Name recommendation

**Precision Machinist Math** is the current recommended store/app name. Current search results show many competitors using names such as Machinist Calc, ShopCalc, Machinist Calculator, CNC Machinist Calculator, and Machinist Toolbox. The proposed name keeps the strong search term **machinist**, adds **math** to distinguish the product's purpose, and signals a serious precision-work tool rather than a generic CNC suite.

Suggested Google Play short description:

> 3-pin bore, threads, fits, triangle, sine bar and precision shop math.

Useful search/ASO terms, where truthful and appropriate:

machinist calculator; machinist math; machine shop calculator; shop math; machining calculator; toolmaker; manual machinist; CNC machinist; precision machining; bore measurement; three pin bore; 3 pin bore; pin gauge; thread calculator; tap drill; metric thread; inch thread; ISO fits; H7; shaft tolerance; hole tolerance; countersink; hardness conversion; right triangle; sine bar; gauge block stack; trig calculator; inspection math; setup math; machine shop; tool and die.

Do not stuff unrelated terms such as feeds/speeds or G-code into the listing unless those functions are actually added.

## Build note

This environment does not contain an Android SDK/Gradle installation, so an installable APK was **not** claimed or fabricated. The Kotlin core was compiled locally and the smoke-test suite passed. The Android project is structured for a normal Android Studio/Gradle build.
