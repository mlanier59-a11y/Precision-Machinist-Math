# Cloud build instructions

This project is prepared to build on GitHub Actions without Android Studio, a local Android SDK, or a local Gradle installation.

1. Create a GitHub repository.
2. Upload the contents of this project to the repository, preserving the `.github/workflows/build-apk.yml` path.
3. Push to the `main` branch, or open **Actions** and run **Build Precision Machinist Math APK** manually.
4. When the workflow finishes, open the workflow run and download the artifact named `Precision-Machinist-Math-beta1-debug`.
5. The artifact contains `app-debug.apk` for installation on an Android test device.

The workflow installs JDK 17, Android SDK platform 35/build tools 35.0.0, and Gradle 8.9 on the cloud runner.
