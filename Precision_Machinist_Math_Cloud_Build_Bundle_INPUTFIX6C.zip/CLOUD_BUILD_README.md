GitHub workflow bundle: INPUTFIX6B
Unzip with:
unzip -q Precision_Machinist_Math_Cloud_Build_Bundle_INPUTFIX6B.zip -d project
Then run Gradle tests and build as before.
