Precision Machinist Math - INPUTFIX6B

Refinements after INPUTFIX6A testing:
- Tap-drill error messages no longer mention thread percentage.
- Right-triangle instruction now reads on two lines: "Enter one angle and one side" / "Or two sides" and is emphasized during error state.
- Hardness invalid-input errors now identify the valid input range for the selected scale from the on-device reference table.
- All INPUTFIX6A hardening behavior retained.
